-- BeanArena.lua
-- TBC Anniversary Arena Point Calculator & Honor Tracker
-- ============================================================
-- VERSION HISTORY
-- ============================================================
-- v0.1.0 | Initial release - arena point calculator
-- v0.1.1 | Honor tracking, BG marks, minimap button
-- v0.1.2 | Arena history tracking, class icons, win/loss
-- v0.1.3 | Resizable history window, per-bracket filters, PVP UI hook
-- v0.1.4 | Per-character history, result filters, bracket detection fix
-- v0.1.5 | 2025-03-01 | Per-char storage via chars table, PLAYER_LOGIN migration
-- v0.1.5.1 | 2025-03-01 | Container API compat fix
-- v0.1.5.2 | 2025-03-01 | Minimap border removed, PVP button removed
-- v0.1.5.3 | 2025-03-01 | Win/loss: guard winner==nil mid-match
-- v0.1.5.4 | 2025-03-01 | Win/loss: switched to UnitIsDeadOrGhost
-- v0.1.5.5 | 2025-03-01 | Kills-based win detection attempt
-- v0.1.5.6 | 2025-03-01 | Fresh win detection rewrite
-- v0.1.5.7 | 2025-03-01 | Win detection partially working
-- v0.1.6 | 2025-03-01 | Removed all arena history tracking and history UI
-- v0.1.7 | 2025-03-01 | Honor cap bar, milestones, gear planner, minimap tooltip
-- v0.1.8 | 2025-03-01 | Two-column layout, EotS fix, individual mark rows
-- v0.1.8.1 | 2025-03-01 | Frame height 420->540
-- v0.1.9 | 2025-03-01 | UI polish, column reorder, inline AP calc, honor gear progress
-- v0.2.0 | 2025-03-01 | Arena Gear Costs popup + Honor Gear Costs popup
-- v0.2.1 | 2025-03-01 | CC/DR Table — all classes, all categories, TBC rules
--         |             Spell Lookup — 80+ spells, filter by class/type/search
-- v0.2.2 | 2026-03-11 | Full embedded spell tooltip DB (97 spells, Blizzard-style)
-- v0.2.3 | 2026-03-11 | Condensed single-col layout, removed Spell Lookup
--         |             Opens attached to PvPUI (H key), flair title + version
--         |             Honor moved to popup button; CC/DR condensed
--         |             Gear cost buttons inline; minimap + /ap unchanged
-- v0.2.4 | 2026-03-11 | Notes popup — 2v2/3v3 comp reference with per-comp notes
--         |             Title right-aligned; 3-button bottom row (+ Notes button)
-- v0.2.7 | 2026-03-11 | Split notes into 2v2 and 3v3 windows; spec-named comps
--         |             tier-ranked S->C; removed default strats; plain-text buttons
-- v0.2.8 | 2026-03-12 | /ba commands; Info button; per-character DB; char viewer
-- v0.2.9 | 2026-03-13 | WoW dialog BG; spacing pass; centered Viewing dropdown; button rows
-- ============================================================
-- v0.3.0 | 2026-03-17 | Full command set: /ba calc, /ba honor [slot], /ba arena [slot], /ba dr [class]
--         |             Minimap: standardized frame, BA text icon, addon-compatible
--         |             Notes: robust persistence (nf.initialized), char-aware reload
-- v0.3.1 | 2026-03-28 | Remove notes buttons, fix ApplyCharView nil crash, fix minimap border
-- v0.3.2 | 2026-05-19 | S2 honor gear table (Veteran's only: Neck/Ring/Bracers/Belt/Boots)
--         |             Rating Target calculator (enter AP goal, shows needed rating per bracket)
-- v0.3.3 | 2026-05-20 | Arena Gear & Honor Gear popups: class dropdown + season toggle (S1/S2)
--         |             Per-class weapon/relic filtering; Veteran's & General's off-pieces by armor type
--         |             Item tooltip on hover for all weapons, off-hands, relics, and honor pieces
-- v0.3.4 | 2026-05-20 | Dedicated Weapons & Relics popup — all variants, one icon per item ID
--         |             Fixes missing relics (3 icons per type, not 1); Weapons button on main frame
--         |             Arena Gear popup now shows armor icon grid with per-class set variants
-- v0.3.5 | 2026-05-20 | Arena Gear: real item icons + full WoW item tooltips (SetHyperlink)
--         |             5-slot icon grid (Head/Chest/Legs/Gloves/Shoulders) x N variant cols
--         |             All 17 S1 + 17 S2 set item IDs from AtlasLootClassic/Data/ItemSet.lua
--         |             Shaman Earthshaker variant added to S1 & S2; Unicode chars fixed
-- v0.3.6 | 2026-05-21 | Unified reference frame with section dropdown
--         |             Arena Gear / Weapons / Honor Gear / CC/DR / Info in one window
--         |             Honor Gear auto-detects player class (no class switcher)
-- CURRENT: v0.3.6
-- ============================================================

-- ============================================================
-- SAVED VARIABLES  (per-character storage in v0.2.8)
-- BeanArenaDB               = global/shared (minimap angle, frame pos)
-- BeanArenaCharDB           = per-character (ratings, honor, comp notes)
-- BeanArenaDB.chars[realm][name] = snapshot of another char's data
-- ============================================================
BeanArenaDB     = BeanArenaDB     or {}
BeanArenaCharDB = BeanArenaCharDB or {}   -- per-char SavedVariable

local ADDON_NAME    = "BeanArena"
local RESET_WEEKDAY = 3 -- Tuesday (wday=3)

-- Character identity (populated on PLAYER_LOGIN)
local CHAR_NAME, CHAR_REALM

local defaults = {
    manual2v2    = 0,
    manual3v3    = 0,
    manual5v5    = 0,
    targetAP     = 0,
    frameX       = nil,
    frameY       = nil,
    openOnLogin  = false,
}

-- Shared DB (global prefs)
local function DB(key)
    if BeanArenaDB[key] == nil then return defaults[key] end
    return BeanArenaDB[key]
end
local function SetDB(key, val) BeanArenaDB[key] = val end

-- Per-character DB (comp notes, snapshots)
local function CharDB(key)
    if BeanArenaCharDB[key] == nil then return nil end
    return BeanArenaCharDB[key]
end
local function SetCharDB(key, val) BeanArenaCharDB[key] = val end

-- Forward-declared so SnapshotCharData/WriteAltSnapshot (defined before the
-- bodies below) capture them as upvalues rather than nil global lookups.
local GetLiveRatings, GetCurrentArenaPoints, GetCurrentHonor

-- Snapshot current char data into the cross-char roster
local function SnapshotCharData()
    if not CHAR_NAME or not CHAR_REALM then return end
    BeanArenaDB.chars = BeanArenaDB.chars or {}
    local key = CHAR_NAME .. "-" .. CHAR_REALM
    local r2,r3,r5,g2,g3,g5 = GetLiveRatings()
    local snap = {
        name         = CHAR_NAME,
        realm        = CHAR_REALM,
        arenaPoints  = GetCurrentArenaPoints(),
        honor        = GetCurrentHonor(),
        r2=r2, r3=r3, r5=r5, g2=g2, g3=g3, g5=g5,
        timestamp    = time(),
    }
    BeanArenaDB.chars[key] = snap
end

-- Write a fresh alt snapshot into BeanArenaDB.altData for the current character.
-- Called on PLAYER_ENTERING_WORLD (delayed 3s so ratings are populated).
local function WriteAltSnapshot()
    if not CHAR_NAME or not CHAR_REALM then return end
    BeanArenaDB.altData = BeanArenaDB.altData or {}
    local key = CHAR_NAME .. "-" .. CHAR_REALM
    local r2,r3,r5,g2,g3,g5 = GetLiveRatings()
    local _, classFile = UnitClass("player")
    BeanArenaDB.altData[key] = {
        name           = CHAR_NAME,
        realm          = CHAR_REALM,
        class          = classFile or "WARRIOR",
        arenaPoints    = GetCurrentArenaPoints(),
        rating2v2      = r2,
        rating3v3      = r3,
        personalRating = math.max(r2, r3, r5),
        honorPoints    = GetCurrentHonor(),
        lastSeen       = time(),
    }
end

-- Returns all alt snapshots sorted by lastSeen descending (most recent first).
function BeanArena_GetAltData()
    local out = {}
    for _, snap in pairs(BeanArenaDB.altData or {}) do
        out[#out+1] = snap
    end
    table.sort(out, function(a, b)
        return (a.lastSeen or 0) > (b.lastSeen or 0)
    end)
    return out
end

-- ============================================================
-- POINT FORMULA
-- ============================================================
local function CalcBasePoints(rating)
    rating = tonumber(rating) or 0
    if rating <= 0 then return 0 end
    return ((1651.94 - 475) / (1 + 2500000 * math.exp(-0.009 * rating)) + 475) * 1.5
end

local function CalcBracketPoints(rating, bracket)
    local base = CalcBasePoints(rating)
    if bracket == "2v2" then return base * 0.76
    elseif bracket == "3v3" then return base * 0.88
    else return base end
end

local function CalcBestPoints(r2, r3, r5)
    local candidates = {
        ["2v2"] = r2 > 0 and CalcBracketPoints(r2, "2v2") or 0,
        ["3v3"] = r3 > 0 and CalcBracketPoints(r3, "3v3") or 0,
        ["5v5"] = r5 > 0 and CalcBracketPoints(r5, "5v5") or 0,
    }
    local best, bestBracket = 0, "None"
    for b, pts in pairs(candidates) do
        if pts > best then best = pts; bestBracket = b end
    end
    return best, bestBracket
end

-- Inverse of CalcBracketPoints: given a target AP and bracket, returns the rating needed.
-- Returns nil if the AP is above the bracket's theoretical maximum (~2478 for 5v5).
-- Returns 0 if the AP is so low any rating achieves it.
local function CalcRatingForPoints(targetAP, bracket)
    local mult = (bracket == "2v2") and 0.76 or (bracket == "3v3") and 0.88 or 1.0
    local base = targetAP / mult
    local inner = base / 1.5 - 475
    if inner <= 0 then return 0 end
    if inner >= 1176.94 then return nil end
    local x = 1176.94 / inner - 1
    if x <= 0 then return nil end
    local rating = -math.log(x / 2500000) / 0.009
    return math.max(0, math.ceil(rating))
end

-- ============================================================
-- GEAR DATA TABLES
-- ============================================================
local ARENA_GEAR_FULL = {
    { slot="Gloves",           ap=930,  rating=0    },
    { slot="Wand",             ap=830,  rating=0    },
    { slot="Caster Off-hand",  ap=930,  rating=0    },
    { slot="Helmet",           ap=1550, rating=0    },
    { slot="Legs",             ap=1550, rating=0    },
    { slot="Chest",            ap=1550, rating=0    },
    { slot="Shoulders",        ap=1245, rating=2000 },
    { slot="Shield",           ap=1550, rating=1700 },
    { slot="Off-hand Melee",   ap=930,  rating=1700 },
    { slot="Throwing Weapon",  ap=830,  rating=1700 },
    { slot="Main-hand Melee",  ap=2175, rating=1700 },
    { slot="Caster Main-hand", ap=2610, rating=1700 },
    { slot="2H / Main Ranged", ap=3110, rating=1700 },
    { slot="Caster Staff",     ap=3110, rating=1700 },
}

-- Season 2 (Veteran's) honor off-pieces only.
-- Main armor slots (helm/chest/legs/shoulders/gloves) come from the Merciless Gladiator arena set.
-- Item IDs from AtlasLoot S2 data: Neck=33066, Ring=33057, Bracers/Belt/Boots per armor type (32xxx).
-- Prices need in-game vendor verification — kept from S1 as placeholder until confirmed.
local HONOR_GEAR_FULL = {
    { slot="Neck",    honor=12695, marks={ EotS=5  } },
    { slot="Ring",    honor=12695, marks={ AV=5    } },
    { slot="Bracers", honor=9785,  marks={ WSG=10  } },
    { slot="Belt",    honor=14815, marks={ AB=10   } },
    { slot="Boots",   honor=14815, marks={ EotS=20 } },
}

-- ============================================================
-- PVP GEAR ITEM DATABASE  (item IDs confirmed from AtlasLoot TBC data)
-- ============================================================

-- Class → armor type (for honor off-piece filtering)
local CLASS_ARMOR_TYPE = {
    Druid="Leather", Hunter="Mail",   Mage="Cloth",
    Paladin="Plate", Priest="Cloth",  Rogue="Leather",
    Shaman="Mail",   Warlock="Cloth", Warrior="Plate",
}
local CLASS_LIST = {"Druid","Hunter","Mage","Paladin","Priest","Rogue","Shaman","Warlock","Warrior"}

-- Arena set variant names per class per season.
-- Each class lists all named set variants (spec-specific); 5 item icons shown per variant.
-- Source: AtlasLootClassic/Data/ItemSet.lua (all item IDs verified).
local CLASS_SETS_S1 = {
    Warrior  = {"Gladiator's Plate"},
    Paladin  = {"Gladiator's Redemption", "Gladiator's Vindication", "Gladiator's Aegis"},
    Druid    = {"Gladiator's Kodohide", "Gladiator's Dragonhide", "Gladiator's Wildhide"},
    Hunter   = {"Gladiator's Chain"},
    Mage     = {"Gladiator's Silk"},
    Priest   = {"Gladiator's Mooncloth", "Gladiator's Satin"},
    Rogue    = {"Gladiator's Leather"},
    Shaman   = {"Gladiator's Mail", "Gladiator's Linked", "Gladiator's Earthshaker"},
    Warlock  = {"Gladiator's Dreadweave", "Gladiator's Felweave"},
}
local CLASS_SETS_S2 = {
    Warrior  = {"Merciless Gladiator's Plate"},
    Paladin  = {"Merciless Gladiator's Redemption", "Merciless Gladiator's Vindication", "Merciless Gladiator's Aegis"},
    Druid    = {"Merciless Gladiator's Kodohide", "Merciless Gladiator's Dragonhide", "Merciless Gladiator's Wildhide"},
    Hunter   = {"Merciless Gladiator's Chain"},
    Mage     = {"Merciless Gladiator's Silk"},
    Priest   = {"Merciless Gladiator's Mooncloth", "Merciless Gladiator's Satin"},
    Rogue    = {"Merciless Gladiator's Leather"},
    Shaman   = {"Merciless Gladiator's Mail", "Merciless Gladiator's Linked", "Merciless Gladiator's Earthshaker"},
    Warlock  = {"Merciless Gladiator's Dreadweave", "Merciless Gladiator's Felweave"},
}

-- Full item ID list per arena set variant name.
-- 5 item IDs per set sourced from AtlasLootClassic/Data/ItemSet.lua (all verified).
-- Items are NOT in slot order; slot is detected at runtime via GetItemInfo equipLoc.
local ARMOR_SET_IDS = {
    -- Season 1 (Gladiator's) ─────────────────────────────────────────────────
    ["Gladiator's Plate"]        = {24545,24546,24544,24549,24547},  -- set 567 Warrior
    ["Gladiator's Dreadweave"]   = {24553,24554,24552,24556,24555},  -- set 568 Warlock
    ["Gladiator's Leather"]      = {25830,25832,25831,25834,25833},  -- set 577 Rogue
    ["Gladiator's Earthshaker"]  = {25998,25999,25997,26000,26001},  -- set 578 Shaman Enh
    ["Gladiator's Silk"]         = {25855,25854,25856,25857,25858},  -- set 579 Mage
    ["Gladiator's Mail"]         = {27471,27473,27469,27470,27472},  -- set 580 Shaman Heal
    ["Gladiator's Satin"]        = {27708,27710,27711,27707,27709},  -- set 581 Priest Shadow
    ["Gladiator's Aegis"]        = {27704,27706,27702,27703,27705},  -- set 582 Paladin Prot
    ["Gladiator's Vindication"]  = {27881,27883,27879,27880,27882},  -- set 583 Paladin Ret
    ["Gladiator's Wildhide"]     = {28127,28129,28130,28126,28128},  -- set 584 Druid Feral
    ["Gladiator's Dragonhide"]   = {28137,28139,28140,28136,28138},  -- set 585 Druid Balance
    ["Gladiator's Chain"]        = {28331,28333,28334,28335,28332},  -- set 586 Hunter
    ["Gladiator's Felweave"]     = {30187,30186,30200,30188,30201},  -- set 615 Warlock
    ["Gladiator's Kodohide"]     = {31376,31378,31379,31375,31377},  -- set 685 Druid Heal
    ["Gladiator's Linked"]       = {31400,31407,31396,31397,31406},  -- set 686 Shaman Ele
    ["Gladiator's Mooncloth"]    = {31410,31412,31413,31409,31411},  -- set 687 Priest Heal
    ["Gladiator's Redemption"]   = {31616,31619,31613,31614,31618},  -- set 690 Paladin Heal
    -- Season 2 (Merciless Gladiator's) ────────────────────────────────────────
    ["Merciless Gladiator's Aegis"]        = {31997,31996,31992,31993,31995},  -- set 700 Paladin Prot
    ["Merciless Gladiator's Plate"]        = {30488,30490,30486,30487,30489},  -- set 701 Warrior
    ["Merciless Gladiator's Dreadweave"]   = {31974,31976,31977,31973,31975},  -- set 702 Warlock
    ["Merciless Gladiator's Earthshaker"]  = {32006,32008,32004,32005,32007},  -- set 703 Shaman Enh
    ["Merciless Gladiator's Felweave"]     = {31980,31979,31982,31981,31983},  -- set 704 Warlock
    ["Merciless Gladiator's Mooncloth"]    = {32016,32018,32019,32015,32017},  -- set 705 Priest Heal
    ["Merciless Gladiator's Chain"]        = {31962,31964,31960,31961,31963},  -- set 706 Hunter
    ["Merciless Gladiator's Satin"]        = {32035,32037,32038,32034,32036},  -- set 707 Priest Shadow
    ["Merciless Gladiator's Redemption"]   = {32022,32024,32020,32021,32023},  -- set 708 Paladin Heal
    ["Merciless Gladiator's Kodohide"]     = {31988,31990,31991,31987,31989},  -- set 709 Druid Heal
    ["Merciless Gladiator's Silk"]         = {32048,32047,32050,32049,32051},  -- set 710 Mage
    ["Merciless Gladiator's Wildhide"]     = {31968,31971,31972,31967,31969},  -- set 711 Druid Feral
    ["Merciless Gladiator's Mail"]         = {32011,32013,32009,32010,32012},  -- set 712 Shaman Heal
    ["Merciless Gladiator's Leather"]      = {31999,32001,32002,31998,32000},  -- set 713 Rogue
    ["Merciless Gladiator's Vindication"]  = {32041,32043,32039,32040,32042},  -- set 714 Paladin Ret
    ["Merciless Gladiator's Linked"]       = {32031,32033,32029,32030,32032},  -- set 715 Shaman Ele
    ["Merciless Gladiator's Dragonhide"]   = {32057,32059,32060,32056,32058},  -- set 716 Druid Balance
}

-- Weapon slot keys each class can equip (used to filter arena weapon list)
local CLASS_WEAPONS = {
    Warrior = {["1H-Sword"]=1,["1H-Axe"]=1,["1H-Mace"]=1,["1H-Fist"]=1,
               ["2H-Sword"]=1,["2H-Axe"]=1,["2H-Mace"]=1,
               ["Shield"]=1,["Thrown"]=1},
    Paladin = {["1H-Mace"]=1,["1H-Sword"]=1,["1H-Axe"]=1,["1H-MaceHeal"]=1,
               ["2H-Mace"]=1,["2H-Sword"]=1,["2H-Axe"]=1,
               ["Shield"]=1,["Libram"]=1},
    Druid   = {["2H-Polearm"]=1,["2H-Staff"]=1,["2H-StaffFeral"]=1,
               ["1H-MaceHeal"]=1,["Off-Tome"]=1,["Idol"]=1},
    Hunter  = {["Crossbow"]=1,["Thrown"]=1,["1H-Sword"]=1,["1H-Axe"]=1,
               ["1H-Fist"]=1,["2H-Sword"]=1,["2H-Axe"]=1,["2H-Polearm"]=1},
    Mage    = {["1H-SwordCaster"]=1,["2H-Staff"]=1,["Wand"]=1,["Off-Orb"]=1},
    Priest  = {["1H-MaceHeal"]=1,["2H-Staff"]=1,["Wand"]=1,["Off-Tome"]=1},
    Rogue   = {["1H-Dagger"]=1,["1H-Sword"]=1,["1H-Mace"]=1,["1H-Fist"]=1,
               ["1H-Axe"]=1,["Thrown"]=1},
    Shaman  = {["1H-Mace"]=1,["1H-Axe"]=1,["1H-Fist"]=1,
               ["2H-Mace"]=1,["2H-Axe"]=1,
               ["Shield"]=1,["Totem"]=1},
    Warlock = {["1H-SwordCaster"]=1,["2H-Staff"]=1,["Wand"]=1,["Off-Orb"]=1},
}

-- Season 2 (Merciless Gladiator's) weapons/offhands/relics with confirmed item IDs
-- ids = list of item variants; first is shown in tooltip header, others listed below
local S2_WEAPONS = {
    {slot="1H Dagger",         key="1H-Dagger",      ids={32044,32046},       ap=2175, rating=1700},
    {slot="1H Sword (Phys)",   key="1H-Sword",       ids={32052,32027},       ap=2175, rating=1700},
    {slot="1H Mace (Phys)",    key="1H-Mace",        ids={32026,31958},       ap=2175, rating=1700},
    {slot="1H Axe",            key="1H-Axe",         ids={31965,31985},       ap=2175, rating=1700},
    {slot="1H Fist Weapon",    key="1H-Fist",        ids={32028,32003},       ap=2175, rating=1700},
    {slot="1H Caster Sword",   key="1H-SwordCaster", ids={32053},             ap=2175, rating=1700},
    {slot="1H Mace (Heal)",    key="1H-MaceHeal",    ids={32963,32964},       ap=2610, rating=1700},
    {slot="2H Sword",          key="2H-Sword",       ids={31984},             ap=3110, rating=1700},
    {slot="2H Axe",            key="2H-Axe",         ids={31966},             ap=3110, rating=1700},
    {slot="2H Mace",           key="2H-Mace",        ids={32014},             ap=3110, rating=1700},
    {slot="2H Polearm",        key="2H-Polearm",     ids={32025},             ap=3110, rating=1700},
    {slot="2H Staff (Caster)", key="2H-Staff",       ids={32055},             ap=3110, rating=1700},
    {slot="2H Staff (Feral)",  key="2H-StaffFeral",  ids={31959},             ap=3110, rating=1700},
    {slot="Crossbow",          key="Crossbow",       ids={31986},             ap=3110, rating=1700},
    {slot="Thrown",            key="Thrown",         ids={32054},             ap=830,  rating=1700},
    {slot="Wand",              key="Wand",           ids={32962},             ap=830,  rating=1700},
    {slot="Shield (Tank/Heal)",key="Shield",         ids={32045},             ap=1550, rating=1700},
    {slot="Shield (DPS/Alt)",  key="Shield",         ids={33309,33313},       ap=1550, rating=1700},
    {slot="Off-hand Tome",     key="Off-Tome",       ids={31978},             ap=930,  rating=1700},
    {slot="Off-hand Orb",      key="Off-Orb",        ids={32961},             ap=930,  rating=1700},
    {slot="Relic — Idol",      key="Idol",           ids={33943,33946,33076}, ap=930,  rating=0   },
    {slot="Relic — Libram",    key="Libram",         ids={33077,33937,33949}, ap=930,  rating=0   },
    {slot="Relic — Totem",     key="Totem",          ids={33078,33952,33940}, ap=930,  rating=0   },
}

-- Season 1 (Gladiator's) weapons/offhands/relics with confirmed item IDs
local S1_WEAPONS = {
    {slot="1H Dagger",         key="1H-Dagger",      ids={28312,28310},       ap=1875, rating=1500},
    {slot="1H Sword (Phys)",   key="1H-Sword",       ids={28295,28307},       ap=1875, rating=1500},
    {slot="1H Mace (Phys)",    key="1H-Mace",        ids={28305,28302},       ap=1875, rating=1500},
    {slot="1H Axe",            key="1H-Axe",         ids={28308,28309},       ap=1875, rating=1500},
    {slot="1H Fist Weapon",    key="1H-Fist",        ids={28313,28314},       ap=1875, rating=1500},
    {slot="1H Caster Sword",   key="1H-SwordCaster", ids={28297},             ap=1875, rating=1500},
    {slot="1H Mace (Heal)",    key="1H-MaceHeal",    ids={32450,32451},       ap=2250, rating=1500},
    {slot="2H Sword",          key="2H-Sword",       ids={24550},             ap=2625, rating=1500},
    {slot="2H Axe",            key="2H-Axe",         ids={28298},             ap=2625, rating=1500},
    {slot="2H Mace",           key="2H-Mace",        ids={28476},             ap=2625, rating=1500},
    {slot="2H Polearm",        key="2H-Polearm",     ids={28300},             ap=2625, rating=1500},
    {slot="2H Staff (Caster)", key="2H-Staff",       ids={24557},             ap=2625, rating=1500},
    {slot="2H Staff (Feral)",  key="2H-StaffFeral",  ids={28299},             ap=2625, rating=1500},
    {slot="Crossbow",          key="Crossbow",       ids={28294},             ap=2625, rating=1500},
    {slot="Thrown",            key="Thrown",         ids={28319},             ap=700,  rating=1500},
    {slot="Wand",              key="Wand",           ids={28320},             ap=700,  rating=1500},
    {slot="Shield",            key="Shield",         ids={28358},             ap=1375, rating=1500},
    {slot="Off-hand Tome",     key="Off-Tome",       ids={28346},             ap=875,  rating=1500},
    {slot="Off-hand Orb",      key="Off-Orb",        ids={32452},             ap=875,  rating=1500},
    {slot="Relic — Idol",      key="Idol",           ids={33942,33945,28355}, ap=875,  rating=0   },
    {slot="Relic — Libram",    key="Libram",         ids={28356,33936,33948}, ap=875,  rating=0   },
    {slot="Relic — Totem",     key="Totem",          ids={28357,33951,33939}, ap=875,  rating=0   },
}

-- S2 Veteran's honor off-pieces by armor type: { id, name, honor, marks }
-- Neck/Ring universal; Bracers/Belt/Boots per armor type (multiple style variants listed)
local S2_HONOR_UNIVERSAL = {
    { slot="Neck", items={
        {id=33066,name="Veteran's Pendant of Triumph"},
        {id=33068,name="Veteran's Pendant of Salvation"},
        {id=33065,name="Veteran's Pendant of Dominance"},
        {id=33067,name="Veteran's Pendant of Conquest"},
    }, honor=12695, marks={EotS=5} },
    { slot="Ring", items={
        {id=33057,name="Veteran's Band of Triumph"},
        {id=33064,name="Veteran's Band of Salvation"},
        {id=33056,name="Veteran's Band of Dominance"},
    }, honor=12695, marks={AV=5} },
}
local S2_HONOR_BYARMOR = {
    Cloth = {
        { slot="Bracers", honor=9785,  marks={WSG=10}, items={
            {id=32820,name="Veteran's Silk Cuffs"},
            {id=32811,name="Veteran's Dreadweave Cuffs"},
            {id=32980,name="Veteran's Mooncloth Cuffs"},
        }},
        { slot="Belt", honor=14815, marks={AB=10}, items={
            {id=32807,name="Veteran's Silk Belt"},
            {id=32799,name="Veteran's Dreadweave Belt"},
            {id=32979,name="Veteran's Mooncloth Belt"},
        }},
        { slot="Boots", honor=14815, marks={EotS=20}, items={
            {id=32795,name="Veteran's Silk Footguards"},
            {id=32787,name="Veteran's Dreadweave Stalkers"},
            {id=32981,name="Veteran's Mooncloth Slippers"},
        }},
    },
    Leather = {
        { slot="Bracers", honor=9785,  marks={WSG=10}, items={
            {id=32810,name="Veteran's Dragonhide Bracers"},
            {id=32814,name="Veteran's Leather Bracers"},
            {id=32812,name="Veteran's Kodohide Bracers"},
            {id=32821,name="Veteran's Wyrmhide Bracers"},
        }},
        { slot="Belt", honor=14815, marks={AB=10}, items={
            {id=32798,name="Veteran's Dragonhide Belt"},
            {id=32802,name="Veteran's Leather Belt"},
            {id=32800,name="Veteran's Kodohide Belt"},
            {id=32808,name="Veteran's Wyrmhide Belt"},
        }},
        { slot="Boots", honor=14815, marks={EotS=20}, items={
            {id=32786,name="Veteran's Dragonhide Boots"},
            {id=32790,name="Veteran's Leather Boots"},
            {id=32788,name="Veteran's Kodohide Boots"},
            {id=32796,name="Veteran's Wyrmhide Boots"},
        }},
    },
    Mail = {
        { slot="Bracers", honor=9785,  marks={WSG=10}, items={
            {id=32997,name="Veteran's Ringmail Bracers"},
            {id=32817,name="Veteran's Mail Bracers"},
            {id=32816,name="Veteran's Linked Bracers"},
            {id=32809,name="Veteran's Chain Bracers"},
        }},
        { slot="Belt", honor=14815, marks={AB=10}, items={
            {id=32998,name="Veteran's Ringmail Girdle"},
            {id=32804,name="Veteran's Mail Girdle"},
            {id=32803,name="Veteran's Linked Girdle"},
            {id=32797,name="Veteran's Chain Girdle"},
        }},
        { slot="Boots", honor=14815, marks={EotS=20}, items={
            {id=32999,name="Veteran's Ringmail Sabatons"},
            {id=32792,name="Veteran's Mail Sabatons"},
            {id=32791,name="Veteran's Linked Sabatons"},
            {id=32785,name="Veteran's Chain Sabatons"},
        }},
    },
    Plate = {
        { slot="Bracers", honor=9785,  marks={WSG=10}, items={
            {id=32819,name="Veteran's Scaled Bracers"},
            {id=32818,name="Veteran's Plate Bracers"},
            {id=32989,name="Veteran's Ornamented Bracers"},
            {id=32813,name="Veteran's Lamellar Bracers"},
        }},
        { slot="Belt", honor=14815, marks={AB=10}, items={
            {id=32806,name="Veteran's Scaled Belt"},
            {id=32805,name="Veteran's Plate Belt"},
            {id=32988,name="Veteran's Ornamented Belt"},
            {id=32801,name="Veteran's Lamellar Belt"},
        }},
        { slot="Boots", honor=14815, marks={EotS=20}, items={
            {id=32794,name="Veteran's Scaled Greaves"},
            {id=32793,name="Veteran's Plate Greaves"},
            {id=32990,name="Veteran's Ornamented Greaves"},
            {id=32789,name="Veteran's Lamellar Greaves"},
        }},
    },
}

-- S1 General's/Marshal's honor off-pieces (faction variants both listed)
local S1_HONOR_UNIVERSAL = {
    { slot="Neck", items={
        {id=28244,name="Pendant of Triumph"},{id=28245,name="Pendant of Dominance"},
    }, honor=11650, marks={} },
    { slot="Ring", items={
        {id=28246,name="Band of Triumph"},{id=28247,name="Band of Dominance"},
    }, honor=11650, marks={} },
}
local S1_HONOR_BYARMOR = {
    Cloth = {
        { slot="Bracers", honor=8910, marks={WSG=10}, items={
            {id=29002,name="Marshal's Silk Cuffs"},{id=28411,name="General's Silk Cuffs"},
            {id=28981,name="Marshal's Dreadweave Cuffs"},{id=28405,name="General's Dreadweave Cuffs"},
            {id=32977,name="Marshal's Mooncloth Cuffs"},{id=32973,name="General's Mooncloth Cuffs"},
        }},
        { slot="Belt", honor=13310, marks={AB=10}, items={
            {id=29001,name="Marshal's Silk Belt"},{id=28409,name="General's Silk Belt"},
            {id=28980,name="Marshal's Dreadweave Belt"},{id=28404,name="General's Dreadweave Belt"},
            {id=32976,name="Marshal's Mooncloth Belt"},{id=32974,name="General's Mooncloth Belt"},
        }},
        { slot="Boots", honor=13310, marks={EotS=20}, items={
            {id=29003,name="Marshal's Silk Footguards"},{id=28410,name="General's Silk Footguards"},
            {id=28982,name="Marshal's Dreadweave Stalkers"},{id=28402,name="General's Dreadweave Stalkers"},
            {id=32978,name="Marshal's Mooncloth Slippers"},{id=32975,name="General's Mooncloth Slippers"},
        }},
    },
    Leather = {
        { slot="Bracers", honor=8910, marks={WSG=10}, items={
            {id=28978,name="Marshal's Dragonhide Bracers"},{id=28445,name="General's Dragonhide Bracers"},
            {id=28988,name="Marshal's Leather Bracers"},{id=28424,name="General's Leather Bracers"},
            {id=31599,name="Marshal's Kodohide Bracers"},{id=31598,name="General's Kodohide Bracers"},
            {id=29006,name="Marshal's Wyrmhide Bracers"},{id=28448,name="General's Wyrmhide Bracers"},
        }},
        { slot="Belt", honor=13310, marks={AB=10}, items={
            {id=28976,name="Marshal's Dragonhide Belt"},{id=28443,name="General's Dragonhide Belt"},
            {id=28986,name="Marshal's Leather Belt"},{id=28423,name="General's Leather Belt"},
            {id=31596,name="Marshal's Kodohide Belt"},{id=31594,name="General's Kodohide Belt"},
            {id=29004,name="Marshal's Wyrmhide Belt"},{id=28446,name="General's Wyrmhide Belt"},
        }},
        { slot="Boots", honor=13310, marks={EotS=20}, items={
            {id=28977,name="Marshal's Dragonhide Boots"},{id=28444,name="General's Dragonhide Boots"},
            {id=28987,name="Marshal's Leather Boots"},{id=28422,name="General's Leather Boots"},
            {id=31597,name="Marshal's Kodohide Boots"},{id=31595,name="General's Kodohide Boots"},
            {id=29005,name="Marshal's Wyrmhide Boots"},{id=28447,name="General's Wyrmhide Boots"},
        }},
    },
    Mail = {
        { slot="Bracers", honor=8910, marks={WSG=10}, items={
            {id=32994,name="Marshal's Ringmail Bracers"},{id=32991,name="General's Ringmail Bracers"},
            {id=28992,name="Marshal's Mail Bracers"},{id=28638,name="General's Mail Bracers"},
            {id=28989,name="Marshal's Linked Bracers"},{id=28605,name="General's Linked Bracers"},
            {id=28973,name="Marshal's Chain Bracers"},{id=28451,name="General's Chain Bracers"},
        }},
        { slot="Belt", honor=13310, marks={AB=10}, items={
            {id=32995,name="Marshal's Ringmail Girdle"},{id=32992,name="General's Ringmail Girdle"},
            {id=28993,name="Marshal's Mail Girdle"},{id=28639,name="General's Mail Girdle"},
            {id=28990,name="Marshal's Linked Girdle"},{id=28629,name="General's Linked Girdle"},
            {id=28974,name="Marshal's Chain Girdle"},{id=28450,name="General's Chain Girdle"},
        }},
        { slot="Boots", honor=13310, marks={EotS=20}, items={
            {id=32996,name="Marshal's Ringmail Sabatons"},{id=32993,name="General's Ringmail Sabatons"},
            {id=28994,name="Marshal's Mail Sabatons"},{id=28640,name="General's Mail Sabatons"},
            {id=28991,name="Marshal's Linked Sabatons"},{id=28630,name="General's Linked Sabatons"},
            {id=28975,name="Marshal's Chain Sabatons"},{id=28449,name="General's Chain Sabatons"},
        }},
    },
    Plate = {
        { slot="Bracers", honor=8910, marks={WSG=10}, items={
            {id=28999,name="Marshal's Scaled Bracers"},{id=28646,name="General's Scaled Bracers"},
            {id=28996,name="Marshal's Plate Bracers"},{id=28381,name="General's Plate Bracers"},
            {id=32986,name="Marshal's Ornamented Bracers"},{id=32983,name="General's Ornamented Bracers"},
            {id=28984,name="Marshal's Lamellar Bracers"},{id=28643,name="General's Lamellar Bracers"},
        }},
        { slot="Belt", honor=13310, marks={AB=10}, items={
            {id=28998,name="Marshal's Scaled Belt"},{id=28644,name="General's Scaled Belt"},
            {id=28995,name="Marshal's Plate Belt"},{id=28385,name="General's Plate Belt"},
            {id=32985,name="Marshal's Ornamented Belt"},{id=32982,name="General's Ornamented Belt"},
            {id=28983,name="Marshal's Lamellar Belt"},{id=28641,name="General's Lamellar Belt"},
        }},
        { slot="Boots", honor=13310, marks={EotS=20}, items={
            {id=29000,name="Marshal's Scaled Greaves"},{id=28645,name="General's Scaled Greaves"},
            {id=28997,name="Marshal's Plate Greaves"},{id=28383,name="General's Plate Greaves"},
            {id=32987,name="Marshal's Ornamented Greaves"},{id=32984,name="General's Ornamented Greaves"},
            {id=28985,name="Marshal's Lamellar Greaves"},{id=28642,name="General's Lamellar Greaves"},
        }},
    },
}

-- ============================================================
-- RESET TIMER
-- ============================================================
local function GetDaysToReset()
    local d = date("*t", time())
    local daysUntilTue = (RESET_WEEKDAY - d.wday + 7) % 7
    if daysUntilTue == 0 then daysUntilTue = d.hour < 8 and 0 or 7 end
    local hoursLeft = (daysUntilTue * 24) + (8 - d.hour - 1)
    local minsLeft  = 60 - d.min
    if minsLeft == 60 then minsLeft = 0; hoursLeft = hoursLeft + 1 end
    return string.format("%dd %dh %dm", math.floor(hoursLeft / 24), hoursLeft % 24, minsLeft)
end

-- ============================================================
-- CURRENCIES
-- ============================================================
local HONOR_CAP = 75000

GetCurrentHonor = function()
    if GetHonorCurrency then
        local h = GetHonorCurrency(); if h then return h end
    end
    if C_CurrencyInfo and C_CurrencyInfo.GetCurrencyInfo then
        local info = C_CurrencyInfo.GetCurrencyInfo(1901)
        if info then return info.quantity or 0 end
    end
    if GetCurrencyInfo then
        local _, count = GetCurrencyInfo(1901); if count then return count end
    end
    return 0
end

GetCurrentArenaPoints = function()
    if GetArenaPoints then
        local pts = GetArenaPoints(); if pts then return pts end
    end
    if C_CurrencyInfo and C_CurrencyInfo.GetCurrencyInfo then
        local info = C_CurrencyInfo.GetCurrencyInfo(1900)
        if info then return info.quantity or 0 end
    end
    if GetCurrencyInfo then
        local _, count = GetCurrencyInfo(1900); if count then return count end
    end
    return 0
end

-- ============================================================
-- PVP MARKS
-- ============================================================
local PVP_MARKS = { [20560]="AV", [20558]="WSG", [20559]="AB", [29024]="EotS" }

local function SafeGetContainerNumSlots(bag)
    if C_Container and C_Container.GetContainerNumSlots then
        return C_Container.GetContainerNumSlots(bag) or 0
    elseif GetContainerNumSlots then return GetContainerNumSlots(bag) or 0 end
    return 0
end
local function SafeGetContainerItemLink(bag, slot)
    if C_Container and C_Container.GetContainerItemLink then
        return C_Container.GetContainerItemLink(bag, slot)
    elseif GetContainerItemLink then return GetContainerItemLink(bag, slot) end
    return nil
end
local function SafeGetContainerItemCount(bag, slot)
    if C_Container and C_Container.GetContainerItemInfo then
        local info = C_Container.GetContainerItemInfo(bag, slot)
        return info and info.stackCount or 1
    elseif GetContainerItemInfo then
        local _, count = GetContainerItemInfo(bag, slot); return count or 1
    end
    return 1
end

local function GetPvPMarkCounts()
    local counts = { AV=0, WSG=0, AB=0, EotS=0 }
    for bag = 0, 4 do
        local numSlots = SafeGetContainerNumSlots(bag)
        for slot = 1, numSlots do
            local link = SafeGetContainerItemLink(bag, slot)
            if link then
                for itemID, markName in pairs(PVP_MARKS) do
                    if link:find("item:" .. itemID .. ":") then
                        counts[markName] = counts[markName] + SafeGetContainerItemCount(bag, slot)
                    end
                end
            end
        end
    end
    return counts
end

-- ============================================================
-- LIVE RATINGS
-- ============================================================
GetLiveRatings = function()
    local r2,r3,r5,g2,g3,g5 = 0,0,0,0,0,0
    if GetPersonalRatedInfo then
        -- GetPersonalRatedInfo: rating, seasonBest, weeklyBest, seasonPlayed, seasonWon, weeklyPlayed, weeklyWon, cap
        local a,_,_,_,_,b = GetPersonalRatedInfo(1); r2=tonumber(a) or 0; g2=tonumber(b) or 0
        local c,_,_,_,_,d = GetPersonalRatedInfo(2); r3=tonumber(c) or 0; g3=tonumber(d) or 0
        local e,_,_,_,_,f = GetPersonalRatedInfo(3); r5=tonumber(e) or 0; g5=tonumber(f) or 0
    end
    return r2,r3,r5,g2,g3,g5
end

-- ============================================================
-- UI HELPERS
-- ============================================================
local function MakeBGFrame(name, parent, w, h)
    -- Detect BackdropTemplate availability (TBC Anniversary supports it)
    local tmpl = (BackdropTemplateMixin ~= nil) and "BackdropTemplate" or nil
    local f = CreateFrame("Frame", name, parent, tmpl)
    f:SetSize(w, h)
    -- Apply backdrop if methods are available (via template or mixin)
    if not f.SetBackdrop and BackdropTemplateMixin then
        Mixin(f, BackdropTemplateMixin)
    end
    if f.SetBackdrop then
        f:SetBackdrop({
            bgFile   = "Interface\\DialogFrame\\UI-DialogBox-Background",
            edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
            tile = true, tileSize = 32, edgeSize = 32,
            insets = { left=11, right=12, top=12, bottom=11 },
        })
        f:SetBackdropColor(0, 0, 0, 1)
        f:SetBackdropBorderColor(1, 1, 1, 1)
    end
    -- Title bar highlight strip
    local tb = f:CreateTexture(nil, "ARTWORK")
    tb:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Header")
    tb:SetSize(w * 0.7, 32)
    tb:SetPoint("TOP", f, "TOP", 0, 10)
    return f
end

local function RegisterEsc(f)
    tinsert(UISpecialFrames, f:GetName())
end

-- Inset "stone panel" section background (like PvP UI bracket panels)
local function MakeSectionBG(parent, x, y, w, h)
    local t = parent:CreateTexture(nil, "BACKGROUND")
    t:SetTexture("Interface\Common\bluemenu-main")
    t:SetTexCoord(0.02, 0.98, 0.02, 0.98)
    t:SetSize(w, h)
    t:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    t:SetAlpha(0.18)
    return t
end

local function MakeHeader(parent, y, text, x)
    local h = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    h:SetPoint("TOPLEFT", parent, "TOPLEFT", x or 18, y)
    h:SetText("|cff00CCFF" .. text .. "|r")
end

local function MakeLine(parent, y, w, x)
    local l = parent:CreateTexture(nil, "ARTWORK")
    l:SetSize(w or 294, 1)
    l:SetPoint("TOPLEFT", parent, "TOPLEFT", x or 18, y)
    l:SetColorTexture(0.4, 0.4, 0.4, 0.6)
end

local function FS(parent, x, y)
    local f = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    f:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    f:SetText("--")
    return f
end

-- ============================================================
-- MINIMAP BUTTON  (reference implementation pattern)
-- DB stored under BeanArenaDB.minimap
-- Textures: overlay=136430, background=136467, icon=achievement_pvp_a_01
-- ============================================================

-- Minimap shape quadrant table — handles non-circular minimaps
local MinimapShapes = {
    ["ROUND"]                  = {true,  true,  true,  true },
    ["SQUARE"]                 = {false, false, false, false},
    ["CORNER-TOPLEFT"]         = {true,  false, false, false},
    ["CORNER-TOPRIGHT"]        = {false, false, true,  false},
    ["CORNER-BOTTOMLEFT"]      = {false, true,  false, false},
    ["CORNER-BOTTOMRIGHT"]     = {false, false, false, true },
    ["SIDE-LEFT"]              = {true,  true,  false, false},
    ["SIDE-RIGHT"]             = {false, false, true,  true },
    ["SIDE-TOP"]               = {true,  false, true,  false},
    ["SIDE-BOTTOM"]            = {false, true,  false, true },
    ["TRICORNER-TOPLEFT"]      = {true,  true,  true,  false},
    ["TRICORNER-TOPRIGHT"]     = {true,  false, true,  true },
    ["TRICORNER-BOTTOMLEFT"]   = {true,  true,  false, true },
    ["TRICORNER-BOTTOMRIGHT"]  = {false, true,  true,  true },
}

local minimapButton = CreateFrame("Button", "BeanArenaMinimapButton", Minimap)
minimapButton:SetFrameStrata("MEDIUM")
minimapButton:SetSize(31, 31)
minimapButton:SetFrameLevel(8)
minimapButton:RegisterForClicks("anyUp")
minimapButton:RegisterForDrag("LeftButton")
minimapButton:SetHighlightTexture(136477) -- UI-Minimap-ZoomButton-Highlight
minimapButton:SetClampedToScreen(true)
minimapButton:SetClampRectInsets(0, -3, 0, 0)

local mmOverlay = minimapButton:CreateTexture(nil, "OVERLAY")
mmOverlay:SetSize(53, 53)
mmOverlay:SetTexture(136430) -- MiniMap-TrackingBorder
mmOverlay:SetPoint("TOPLEFT")

local mmBackground = minimapButton:CreateTexture(nil, "BACKGROUND")
mmBackground:SetSize(20, 20)
mmBackground:SetTexture(136467) -- UI-Minimap-Background
mmBackground:SetPoint("TOPLEFT", 7, -5)

local mmIcon = minimapButton:CreateTexture(nil, "ARTWORK")
mmIcon:SetSize(17, 17)
mmIcon:SetTexture("Interface\\Icons\\achievement_pvp_a_01")
mmIcon:SetPoint("TOPLEFT", 7, -6)

-- icon zoom: pull edges in slightly when not pressed
local function MMIconZoom(isDown)
    local d = isDown and 0 or 0.05
    mmIcon:SetTexCoord(d, 1-d, d, 1-d)
end
MMIconZoom(false)

local mmIsDragging = false
local mmIsDown = false

local function UpdateMinimapPos()
    local mmDB = BeanArenaDB.minimap
    -- radius offset + distance ratio, matching the reference exactly
    local w = (math.floor(Minimap:GetWidth()  / 2) + 10) * mmDB.distance
    local h = (math.floor(Minimap:GetHeight() / 2) + 10) * mmDB.distance
    local angle = math.rad(mmDB.position)
    local x = math.cos(angle)
    local y = math.sin(angle)
    -- quadrant: 1=upper-left, 2=lower-left, 3=upper-right, 4=lower-right
    local q = 1
    if x < 0 then q = q + 1 end
    if y > 0 then q = q + 2 end
    local shape = GetMinimapShape and GetMinimapShape() or "ROUND"
    local quadTable = MinimapShapes[shape] or MinimapShapes["ROUND"]
    if quadTable[q] then
        x = x * w
        y = y * h
    else
        local diagW = math.sqrt(2 * w^2) - 10
        local diagH = math.sqrt(2 * h^2) - 10
        x = math.max(-w, math.min(x * diagW, w))
        y = math.max(-h, math.min(y * diagH, h))
    end
    minimapButton:SetPoint("CENTER", Minimap, "CENTER", x, y)
end

minimapButton:SetScript("OnDragStart", function(self)
    mmIsDown = true
    if BeanArenaDB.minimap.lock then return end
    self:LockHighlight()
    MMIconZoom(false)
    mmIsDragging = true
    GameTooltip:Hide()
    self:SetScript("OnUpdate", function()
        local mx, my = Minimap:GetCenter()
        local px, py = GetCursorPosition()
        local scale  = Minimap:GetEffectiveScale()
        px, py = px / scale, py / scale
        local dx, dy = px - mx, py - my
        BeanArenaDB.minimap.position = math.deg(math.atan2(dy, dx)) % 360
        if BeanArenaDB.minimap.lockDistance then
            BeanArenaDB.minimap.distance = 1
        else
            local radius = (Minimap:GetWidth() / 2) + 5
            local dist = math.sqrt(dx*dx + dy*dy) / radius
            BeanArenaDB.minimap.distance = math.max(1, math.min(dist, 2))
        end
        UpdateMinimapPos()
    end)
end)

minimapButton:SetScript("OnDragStop", function(self)
    self:SetScript("OnUpdate", nil)
    mmIsDown = false
    MMIconZoom(false)
    self:UnlockHighlight()
    mmIsDragging = false
end)

minimapButton:SetScript("OnMouseDown", function()
    mmIsDown = true
    MMIconZoom(true)
end)

minimapButton:SetScript("OnMouseUp", function()
    mmIsDown = false
    MMIconZoom(false)
end)

minimapButton:SetScript("OnEnter", function(self)
    if mmIsDragging then return end
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:SetText("|cffFFD700BeanArena|r", 1, 1, 1)
    local honor = GetCurrentHonor()
    local ap    = GetCurrentArenaPoints()
    local r2,r3,r5,g2,g3,g5 = GetLiveRatings()
    local er2=g2>=10 and r2 or 0; local er3=g3>=10 and r3 or 0; local er5=g5>=10 and r5 or 0
    local best,bb = CalcBestPoints(er2,er3,er5)
    local honorPct = math.min(100, math.floor(honor / HONOR_CAP * 100))
    GameTooltip:AddLine(string.format("Honor: |cffFFD700%s|r / 75,000  (%d%%)",
        BreakUpLargeNumbers and BreakUpLargeNumbers(honor) or tostring(honor), honorPct), 0.8,0.8,0.8)
    if honor >= 70000 then GameTooltip:AddLine("|cffFF4444Warning: Near honor cap! Spend soon.|r") end
    GameTooltip:AddLine(string.format("Arena Points: |cff88FF88%d|r", ap), 0.8,0.8,0.8)
    if best > 0 then
        GameTooltip:AddLine(string.format("Best reward: |cffFFD700%.0f AP|r  (%s)", best, bb), 0.8,0.8,0.8)
    end
    GameTooltip:AddLine(" ")
    GameTooltip:AddLine("Left-click: toggle window",  0.6,0.6,0.6)
    GameTooltip:AddLine("Middle-click: commands",     0.6,0.6,0.6)
    GameTooltip:AddLine("Right-click: options",       0.6,0.6,0.6)
    GameTooltip:Show()
end)

minimapButton:SetScript("OnLeave", function() GameTooltip:Hide() end)

-- ============================================================
-- FORWARD DECLARATIONS
-- ============================================================
local OpenBeanArena, OpenCommands, frame, cFrame, SetupPVPHook
local honorFrame, charViewFrame, refFrame
local BeanArena_RefreshRefFrame, BeanArena_OpenRefFrame
local BeanArena_RefreshHonorFrame
local BeanArena_RefreshFrame, BeanArena_RefreshManual

-- ============================================================
-- OPTIONS DROPDOWN
-- ============================================================
local optDD = CreateFrame("Frame", "BeanArenaOptDD", UIParent, "UIDropDownMenuTemplate")

local function ShowOptions()
    UIDropDownMenu_Initialize(optDD, function()
        local function Btn(text, func, checked, notCheckable)
            local i = {}
            i.text = text; i.func = func; i.checked = checked
            i.notCheckable = notCheckable or false; i.isNotRadio = notCheckable or false
            i.disabled = false; i.isTitle = false; i.keepShownOnClick = false
            UIDropDownMenu_AddButton(i)
        end
        local function Title(text)
            local i = {}
            i.text = text; i.isTitle = true; i.notCheckable = true; i.disabled = true
            UIDropDownMenu_AddButton(i)
        end
        Title("|cffFFD700BeanArena Options|r")
        Btn("Toggle BeanArena Window", function()
            if frame:IsShown() then frame:Hide() else OpenBeanArena() end
            CloseDropDownMenus()
        end, nil, true)
        Btn("Toggle Commands Window", function()
            if cFrame:IsShown() then cFrame:Hide() else OpenCommands() end
            CloseDropDownMenus()
        end, nil, true)
        Title("Startup")
        Btn("Open on Login", function()
            SetDB("openOnLogin", not DB("openOnLogin"))
            CloseDropDownMenus()
        end, DB("openOnLogin"), false)
    end, "MENU")
    ToggleDropDownMenu(1, nil, optDD, "cursor", 0, 0)
end

minimapButton:SetScript("OnClick", function(self, btn)
    if btn == "LeftButton" then
        if frame:IsShown() then frame:Hide() else OpenBeanArena() end
    elseif btn == "MiddleButton" then
        if cFrame:IsShown() then cFrame:Hide() else OpenCommands() end
    elseif btn == "RightButton" then
        ShowOptions()
    end
end)

-- ============================================================
-- LAYOUT CONSTANTS  (condensed single-column main frame)
-- ============================================================
local FW, FH = 430, 510   -- expanded for Rating Target section
local LC = 18
local CW = FW - 36

-- Y positions — all in one table to stay under 200-local limit
local Y = {
    -- Arena Ratings  (extra padding around dividers)
    LHEAD   = -42,  LLINE1  = -58,  LCOLHDR = -70,
    LLINE2  = -83,  L2V2    = -97,  L3V3    = -117,
    L5V5    = -137, LLINE3  = -155,
    LBANKED = -168, LLINE4  = -185,
    -- Arena Point Calculator
    MHEAD   = -200, MLINE1  = -215, MCALCHDR= -227,
    MLINE1B = -240, M2V2    = -254, M3V3    = -274,
    M5V5    = -294, MLINE2  = -312,
    -- Rating Target (AP → Rating)
    TLINE   = -318, THEAD   = -330, TLINE2  = -343,
    TINPUT  = -358, TRES    = -378, TLINE3  = -395,
    -- Bottom button rows (shifted down from original -330/-355/-380)
    BTNS    = -410, BTNROW2 = -430, CHARDD  = -453,
}

-- ============================================================
-- MAIN FRAME
-- ============================================================
frame = MakeBGFrame("BeanArenaFrame", UIParent, FW, FH)
frame:SetFrameStrata("MEDIUM")
frame:SetMovable(true); frame:EnableMouse(true)
frame:RegisterForDrag("LeftButton")
frame:SetScript("OnDragStart", frame.StartMoving)
frame:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    local x, y = self:GetCenter(); SetDB("frameX", x); SetDB("frameY", y)
end)
frame:Hide()
RegisterEsc(frame)

-- ── Title — right-aligned to avoid overlap with top-left buttons ─
local titleFS = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
titleFS:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -36, -10)
titleFS:SetText("|cffFF6600«|r |cffFFD700BeanArena|r |cffFF6600»|r")
titleFS:SetJustifyH("RIGHT")

local versionFS = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
versionFS:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -36, -27)
versionFS:SetText("|cff666666v0.3.3  •  TBC Anniversary|r")
versionFS:SetJustifyH("RIGHT")

local mainClose = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
mainClose:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -4, -4)
mainClose:SetScript("OnClick", function() frame:Hide() end)



-- ── Helpers scoped to main frame ─────────────────────────────
local function SmallHdr(x, y, txt)
    local f = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    f:SetPoint("TOPLEFT", frame, "TOPLEFT", x, y)
    f:SetText("|cffAAAAAA" .. txt .. "|r")
end

-- ══════════════════════════════════════════════════════════════
-- SECTION: CURRENT ARENA RATINGS
-- ══════════════════════════════════════════════════════════════
MakeHeader(frame, Y.LHEAD, "Current Arena Ratings", LC)
MakeLine(frame, Y.LLINE1, CW, LC)

-- Bracket | Games | Rating | Reward AP | Total AP
local LCOL = { br=LC, gms=LC+60, rat=LC+112, pts=LC+182, tot=LC+268 }
SmallHdr(LCOL.br,  Y.LCOLHDR, "Bracket")
SmallHdr(LCOL.gms, Y.LCOLHDR, "Games")
SmallHdr(LCOL.rat, Y.LCOLHDR, "Rating")
SmallHdr(LCOL.pts, Y.LCOLHDR, "Reward AP")
SmallHdr(LCOL.tot, Y.LCOLHDR, "Total AP")
MakeLine(frame, Y.LLINE2, CW, LC)

local function LiveRow(y, label)
    local l = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    l:SetPoint("TOPLEFT", frame, "TOPLEFT", LCOL.br, y)
    l:SetText(label); l:SetTextColor(0.8, 0.8, 0.8)
    local function F(x) return FS(frame, x, y) end
    -- liveR=rating, liveG=games, liveP=reward AP, liveT=total AP
    return F(LCOL.rat), F(LCOL.gms), F(LCOL.pts), F(LCOL.tot)
end

local liveR2, liveG2, liveP2, liveT2 = LiveRow(Y.L2V2, "2v2")
local liveR3, liveG3, liveP3, liveT3 = LiveRow(Y.L3V3, "3v3")
local liveR5, liveG5, liveP5, liveT5 = LiveRow(Y.L5V5, "5v5")
MakeLine(frame, Y.LLINE3, CW, LC)

local apLbl = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
apLbl:SetPoint("TOPLEFT", frame, "TOPLEFT", LC, Y.LBANKED)
apLbl:SetText("Banked AP:"); apLbl:SetTextColor(0.8, 0.8, 0.8)
local apInlineVal = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
apInlineVal:SetPoint("LEFT", apLbl, "RIGHT", 8, 0); apInlineVal:SetText("--")

-- ══════════════════════════════════════════════════════════════
-- SECTION: ARENA POINT CALCULATOR
-- ══════════════════════════════════════════════════════════════
MakeLine(frame, Y.LLINE4, CW, LC)
MakeHeader(frame, Y.MHEAD, "Arena Point Calculator", LC)
MakeLine(frame, Y.MLINE1, CW, LC)

local CALC = { lbl=LC, eb=LC+110, res=LC+240 }
SmallHdr(CALC.lbl, Y.MCALCHDR, "Bracket")
SmallHdr(CALC.eb,  Y.MCALCHDR, "Rating")
SmallHdr(CALC.res, Y.MCALCHDR, "Arena Points")
MakeLine(frame, Y.MLINE1B, CW, LC)

local editFocused = {}
local manResultFS = {}

local function MakeCalcRow(y, labelText, dbKey, bracket)
    local l = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    l:SetPoint("TOPLEFT", frame, "TOPLEFT", CALC.lbl, y)
    l:SetText(labelText); l:SetTextColor(0.8, 0.8, 0.8)
    local eb = CreateFrame("EditBox", nil, frame, "InputBoxTemplate")
    eb:SetSize(88, 20)
    eb:SetPoint("TOPLEFT", frame, "TOPLEFT", CALC.eb, y + 4)
    eb:SetAutoFocus(false); eb:SetNumeric(true); eb:SetMaxLetters(4)
    eb:SetText(tostring(DB(dbKey)))
    eb:SetScript("OnEditFocusGained", function() editFocused[dbKey] = true end)
    eb:SetScript("OnEditFocusLost", function(self)
        editFocused[dbKey] = nil
        SetDB(dbKey, tonumber(self:GetText()) or 0)
        BeanArena_RefreshManual()
    end)
    eb:SetScript("OnEnterPressed", function(self)
        SetDB(dbKey, tonumber(self:GetText()) or 0)
        self:ClearFocus(); BeanArena_RefreshManual()
    end)
    eb:SetScript("OnEscapePressed", function(self)
        self:SetText(tostring(DB(dbKey))); self:ClearFocus()
    end)
    local res = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    res:SetPoint("TOPLEFT", frame, "TOPLEFT", CALC.res, y); res:SetText("--")
    manResultFS[bracket] = res
    return eb
end

local man2v2Edit = MakeCalcRow(Y.M2V2, "2v2:", "manual2v2", "2v2")
local man3v3Edit = MakeCalcRow(Y.M3V3, "3v3:", "manual3v3", "3v3")
local man5v5Edit = MakeCalcRow(Y.M5V5, "5v5:", "manual5v5", "5v5")

MakeLine(frame, Y.MLINE2, CW, LC)

-- ══════════════════════════════════════════════════════════════
-- SECTION: RATING TARGET  (AP → Rating inverse calculator)
-- ══════════════════════════════════════════════════════════════
MakeLine(frame, Y.TLINE, CW, LC)
MakeHeader(frame, Y.THEAD, "Rating Target", LC)
MakeLine(frame, Y.TLINE2, CW, LC)

SmallHdr(CALC.lbl,  Y.TINPUT + 10, "AP Goal")

local targetLbl = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
targetLbl:SetPoint("TOPLEFT", frame, "TOPLEFT", CALC.lbl, Y.TINPUT)
targetLbl:SetText("Target AP:"); targetLbl:SetTextColor(0.8, 0.8, 0.8)

local targetResultFS = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
targetResultFS:SetPoint("TOPLEFT", frame, "TOPLEFT", LC, Y.TRES)
targetResultFS:SetWidth(CW)
targetResultFS:SetText("--")

local targetAPEdit = CreateFrame("EditBox", nil, frame, "InputBoxTemplate")
targetAPEdit:SetSize(88, 20)
targetAPEdit:SetPoint("TOPLEFT", frame, "TOPLEFT", CALC.eb, Y.TINPUT + 4)
targetAPEdit:SetAutoFocus(false); targetAPEdit:SetNumeric(true); targetAPEdit:SetMaxLetters(4)
targetAPEdit:SetText(DB("targetAP") > 0 and tostring(DB("targetAP")) or "")

local RefreshTargetCalc
targetAPEdit:SetScript("OnEditFocusGained", function() editFocused["targetAP"] = true end)
targetAPEdit:SetScript("OnEditFocusLost", function(self)
    editFocused["targetAP"] = nil
    SetDB("targetAP", tonumber(self:GetText()) or 0)
    RefreshTargetCalc()
end)
targetAPEdit:SetScript("OnEnterPressed", function(self)
    SetDB("targetAP", tonumber(self:GetText()) or 0)
    self:ClearFocus(); RefreshTargetCalc()
end)
targetAPEdit:SetScript("OnEscapePressed", function(self)
    local v = DB("targetAP")
    self:SetText(v > 0 and tostring(v) or ""); self:ClearFocus()
end)

local BRACKET_MAX_AP = { ["2v2"] = 1883, ["3v3"] = 2181, ["5v5"] = 2478 }

RefreshTargetCalc = function()
    local ap = DB("targetAP")
    if ap <= 0 then
        targetResultFS:SetText("|cff666666—|r")
        return
    end
    local parts = {}
    for _, bkt in ipairs({"2v2", "3v3", "5v5"}) do
        local r = CalcRatingForPoints(ap, bkt)
        if r == nil then
            parts[#parts+1] = string.format("%s: |cffFF4444n/a|r|cff666666(~%d max)|r", bkt, BRACKET_MAX_AP[bkt])
        elseif r == 0 then
            parts[#parts+1] = bkt .. ": |cff00FF00any|r"
        else
            parts[#parts+1] = bkt .. ": |cffFFD700" .. tostring(r) .. "|r"
        end
    end
    targetResultFS:SetText(table.concat(parts, "  |cff444444·|r  "))
end

MakeLine(frame, Y.TLINE3, CW, LC)

-- ── Row 1: Arena Gear | Weapons | Honor Gear ──────────────────────────
local BTNW2 = math.floor((CW - 4) / 2)

local refMainBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
refMainBtn:SetSize(BTNW2, 20)
refMainBtn:SetPoint("TOPLEFT", frame, "TOPLEFT", LC, Y.BTNS)
refMainBtn:SetText("Reference")
refMainBtn:GetFontString():SetFontObject("GameFontNormalSmall")
refMainBtn:SetScript("OnClick", function()
    if refFrame:IsShown() then refFrame:Hide()
    else refFrame:ClearAllPoints()
        refFrame:SetPoint("TOPLEFT", frame, "TOPRIGHT", 6, 0); refFrame:Show() end
end)

local honorMainBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
honorMainBtn:SetSize(BTNW2, 20)
honorMainBtn:SetPoint("LEFT", refMainBtn, "RIGHT", 4, 0)
honorMainBtn:SetText("Honor")
honorMainBtn:GetFontString():SetFontObject("GameFontNormalSmall")
honorMainBtn:SetScript("OnClick", function()
    if honorFrame:IsShown() then honorFrame:Hide()
    else honorFrame:ClearAllPoints()
        honorFrame:SetPoint("TOPLEFT", frame, "TOPRIGHT", 6, 0); honorFrame:Show() end
end)

-- ── Character dropdown row (centered) ───────────────────────
local charDDLbl = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
charDDLbl:SetPoint("TOP", frame, "TOP", 0, Y.CHARDD + 16)
charDDLbl:SetText("|cff888888Viewing:|r")
charDDLbl:SetJustifyH("CENTER")

local charDD = CreateFrame("Frame", "BeanArenaCharDD", frame, "UIDropDownMenuTemplate")
UIDropDownMenu_SetWidth(charDD, 260)
charDD:SetPoint("TOP", frame, "TOP", 0, Y.CHARDD - 4)

-- Track which character's data is being shown (nil = current char)
local viewingSnap = nil  -- nil means live/current char

local function GetAllCharSnaps()
    local snaps = {}
    local chars = BeanArenaDB.chars or {}
    for key, snap in pairs(chars) do
        if type(snap) == "table" and snap.name then
            snaps[#snaps+1] = snap
        end
    end
    table.sort(snaps, function(a,b) return (a.name or "") < (b.name or "") end)
    return snaps
end

local function ApplyCharView(snap)
    viewingSnap = snap
    if snap == nil then
        -- Restore live data for current character
        UIDropDownMenu_SetText(charDD, "|cffFFD700" .. (CHAR_NAME or "Current") .. " (you)|r")
        if UIDropDownMenu_JustifyText then UIDropDownMenu_JustifyText(charDD, "CENTER") end
        BeanArena_RefreshFrame()
    else
        -- Show a different character's snapshot
        UIDropDownMenu_SetText(charDD, snap.name)
        if UIDropDownMenu_JustifyText then UIDropDownMenu_JustifyText(charDD, "CENTER") end
        liveR2:SetText(snap.r2 and tostring(snap.r2) or "|cff666666--|r")
        liveG2:SetText(snap.g2 and tostring(snap.g2) or "|cff666666--|r")
        liveP2:SetText(snap.r2 and string.format("|cffFFD700%.0f|r", CalcBracketPoints(snap.r2 or 0,"2v2")) or "|cff666666--|r")
        liveR3:SetText(snap.r3 and tostring(snap.r3) or "|cff666666--|r")
        liveG3:SetText(snap.g3 and tostring(snap.g3) or "|cff666666--|r")
        liveP3:SetText(snap.r3 and string.format("|cffFFD700%.0f|r", CalcBracketPoints(snap.r3 or 0,"3v3")) or "|cff666666--|r")
        liveR5:SetText(snap.r5 and tostring(snap.r5) or "|cff666666--|r")
        liveG5:SetText(snap.g5 and tostring(snap.g5) or "|cff666666--|r")
        liveP5:SetText(snap.r5 and string.format("|cffFFD700%.0f|r", CalcBracketPoints(snap.r5 or 0,"5v5")) or "|cff666666--|r")
        local sap = snap.arenaPoints or 0
        local sp2 = snap.r2 and CalcBracketPoints(snap.r2,"2v2") or 0
        local sp3 = snap.r3 and CalcBracketPoints(snap.r3,"3v3") or 0
        local sp5 = snap.r5 and CalcBracketPoints(snap.r5,"5v5") or 0
        liveT2:SetText(sp2>0 and string.format("|cff88FF88%.0f|r", sap+sp2) or "|cff666666--|r")
        liveT3:SetText(sp3>0 and string.format("|cff88FF88%.0f|r", sap+sp3) or "|cff666666--|r")
        liveT5:SetText(sp5>0 and string.format("|cff88FF88%.0f|r", sap+sp5) or "|cff666666--|r")
        apInlineVal:SetText(sap > 0 and string.format("|cff88FF88%d|r", sap) or "|cff666666--|r")
    end
end

UIDropDownMenu_Initialize(charDD, function()
    if UIDropDownMenu_JustifyText then UIDropDownMenu_JustifyText(charDD, "CENTER") end
    local info = UIDropDownMenu_CreateInfo()
    -- "Current character" entry
    info.text = "|cffFFD700" .. (CHAR_NAME or "Current") .. " (you)|r"
    info.value = "SELF"
    info.notCheckable = false
    info.checked = (viewingSnap == nil)
    info.func = function() ApplyCharView(nil); CloseDropDownMenus() end
    UIDropDownMenu_AddButton(info)

    local snaps = GetAllCharSnaps()
    for _, snap in ipairs(snaps) do
        if not (snap.name == CHAR_NAME and snap.realm == CHAR_REALM) then
            local i = UIDropDownMenu_CreateInfo()
            i.text = snap.name .. " |cff888888(" .. (snap.realm or "?") .. ")|r"
            i.value = snap.name
            i.notCheckable = false
            i.checked = (viewingSnap and viewingSnap.name == snap.name)
            i.func = function()
                SnapshotCharData()
                ApplyCharView(snap)
                CloseDropDownMenus()
            end
            UIDropDownMenu_AddButton(i)
        end
    end
end)

-- ============================================================
-- POPUP: HONOR WINDOW
-- Full honor data, marks, weekly plan, gear progress.
-- ============================================================
do
    local PW  = 430
    local PRC = 18
    local PCW = PW - 36
    local PBAR= PCW - 4
    local PH  = 374 + #HONOR_GEAR_FULL * 18 + 20

    honorFrame = MakeBGFrame("BeanArenaHonorFrame", UIParent, PW, PH)
    honorFrame:SetFrameStrata("HIGH")
    honorFrame:SetMovable(true); honorFrame:EnableMouse(true)
    honorFrame:RegisterForDrag("LeftButton")
    honorFrame:SetScript("OnDragStart", honorFrame.StartMoving)
    honorFrame:SetScript("OnDragStop", function(s) s:StopMovingOrSizing() end)
    honorFrame:Hide()
    RegisterEsc(honorFrame)

    local ht = honorFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    ht:SetPoint("TOP", honorFrame, "TOP", 0, -10)
    ht:SetText("|cffFFD700Honor|r")

    local hcBtn = CreateFrame("Button", nil, honorFrame, "UIPanelCloseButton")
    hcBtn:SetPoint("TOPRIGHT", honorFrame, "TOPRIGHT", -4, -4)
    hcBtn:SetScript("OnClick", function() honorFrame:Hide() end)

    local function HRow(y, lbl)
        local l = honorFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        l:SetPoint("TOPLEFT", honorFrame, "TOPLEFT", PRC, y)
        l:SetText(lbl); l:SetTextColor(0.8, 0.8, 0.8)
        local v = honorFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        v:SetPoint("TOPLEFT", honorFrame, "TOPLEFT", PRC + 148, y)
        v:SetText("--"); return v
    end
    local function HLine(y) MakeLine(honorFrame, y, PCW, PRC) end
    local function HHead(y, t) MakeHeader(honorFrame, y, t, PRC) end

    HHead(-28, "Current Status"); HLine(-42)
    local hHonorVal   = HRow(-53,  "Current Honor:")
    local hResetVal   = HRow(-71,  "Reset In:")
    local hArenaAPVal = HRow(-89,  "Arena Points:")

    HLine(-105)
    local hBarBG = honorFrame:CreateTexture(nil, "BACKGROUND")
    hBarBG:SetSize(PBAR, 16)
    hBarBG:SetPoint("TOPLEFT", honorFrame, "TOPLEFT", PRC, -116)
    hBarBG:SetColorTexture(0.12, 0.12, 0.12, 0.9)

    local hBarFill = honorFrame:CreateTexture(nil, "ARTWORK")
    hBarFill:SetSize(1, 16)
    hBarFill:SetPoint("TOPLEFT", hBarBG, "TOPLEFT", 0, 0)
    hBarFill:SetColorTexture(0.85, 0.75, 0.1, 1)

    local hBarText = honorFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    hBarText:SetPoint("CENTER", hBarBG, "CENTER", 0, 0)
    hBarText:SetText("0 / 75,000")

    local hCapWarn = honorFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    hCapWarn:SetPoint("TOPLEFT", honorFrame, "TOPLEFT", PRC, -138)
    hCapWarn:SetText("")

    HLine(-153); HHead(-163, "PvP Marks in Bags"); HLine(-177)
    local hMkAV   = HRow(-188, "AV:")
    local hMkWSG  = HRow(-206, "WSG:")
    local hMkAB   = HRow(-224, "AB:")
    local hMkEotS = HRow(-242, "EotS:")

    HLine(-258); HHead(-268, "Weekly Honor Plan"); HLine(-282)
    local hPlanText = honorFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    hPlanText:SetPoint("TOPLEFT", honorFrame, "TOPLEFT", PRC, -293)
    hPlanText:SetWidth(PCW - 8); hPlanText:SetJustifyH("LEFT")
    hPlanText:SetText("--")

    HLine(-318); HHead(-328, "Honor Gear Progress"); HLine(-342)

    local HGC = { slot=PRC, marks=PRC+55, honor=PRC+190, status=PRC+305 }
    local function HSHdr(x, y, t)
        local f = honorFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        f:SetPoint("TOPLEFT", honorFrame, "TOPLEFT", x, y)
        f:SetText("|cffAAAAAA" .. t .. "|r")
    end
    HSHdr(HGC.slot, -352, "Slot"); HSHdr(HGC.marks, -352, "Marks Needed")
    HSHdr(HGC.honor, -352, "Honor"); HSHdr(HGC.status, -352, "Ready?")
    MakeLine(honorFrame, -363, PCW, PRC)

    local honorGearRowsH = {}
    for i, gear in ipairs(HONOR_GEAR_FULL) do
        local y = -374 - (i - 1) * 18
        local slotFS = honorFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        slotFS:SetPoint("TOPLEFT", honorFrame, "TOPLEFT", HGC.slot, y)
        slotFS:SetText(gear.slot); slotFS:SetTextColor(0.85, 0.85, 0.85)
        local marksFS = honorFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        marksFS:SetPoint("TOPLEFT", honorFrame, "TOPLEFT", HGC.marks, y)
        marksFS:SetText("--")
        local honorFS = honorFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        honorFS:SetPoint("TOPLEFT", honorFrame, "TOPLEFT", HGC.honor, y)
        honorFS:SetText("--")
        local statusFS = honorFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        statusFS:SetPoint("TOPLEFT", honorFrame, "TOPLEFT", HGC.status, y)
        statusFS:SetText("--")
        honorGearRowsH[i] = { gear=gear, marksFS=marksFS, honorFS=honorFS, statusFS=statusFS }
    end

    local function RefreshHonorFrame()
        local honor = GetCurrentHonor()
        local ap    = GetCurrentArenaPoints()
        local marks = GetPvPMarkCounts()
        local fmt   = BreakUpLargeNumbers or tostring

        hHonorVal:SetText(string.format("|cffFFD700%s|r", fmt(honor)))
        hArenaAPVal:SetText(string.format("|cff88FF88%s|r", fmt(ap)))
        hResetVal:SetText("|cff00CCFF" .. GetDaysToReset() .. "|r")

        hMkAV:SetText(string.format("|cffFFD700%d|r", marks.AV or 0))
        hMkWSG:SetText(string.format("|cffFFD700%d|r", marks.WSG or 0))
        hMkAB:SetText(string.format("|cffFFD700%d|r", marks.AB or 0))
        hMkEotS:SetText(string.format("|cffFFD700%d|r", marks.EotS or 0))

        local pct = math.min(1, honor / HONOR_CAP)
        hBarFill:SetWidth(math.max(1, math.floor(PBAR * pct)))
        hBarText:SetText(string.format("%s / 75,000  (%d%%)", fmt(honor), math.floor(pct * 100)))
        if honor >= 70000 then
            hCapWarn:SetText("|cffFF4444Warning: Near cap — spend before 75k or gains are lost!|r")
            hBarFill:SetColorTexture(1, 0.2, 0.2, 1)
        elseif honor >= 55000 then
            hCapWarn:SetText("|cffFFAA00Getting full — consider spending soon.|r")
            hBarFill:SetColorTexture(1, 0.7, 0.1, 1)
        else
            hCapWarn:SetText("")
            hBarFill:SetColorTexture(0.85, 0.75, 0.1, 1)
        end

        local toFill = math.max(0, HONOR_CAP - honor)
        if toFill == 0 then
            hPlanText:SetText("|cff00FF00Honor capped! Time to spend.|r")
        else
            hPlanText:SetText(string.format(
                "|cffAAAAAA~%d AV wins to cap|r  |cff666666(or ~%d WSG/AB/EotS)|r",
                math.ceil(toFill / 419), math.ceil(toFill / 209)))
        end

        for _, row in ipairs(honorGearRowsH) do
            local gear     = row.gear
            local honorMet = honor >= gear.honor
            local allMet   = true
            local mparts   = {}
            for bg, req in pairs(gear.marks) do
                local have = marks[bg] or 0
                local met  = have >= req
                if not met then allMet = false end
                table.insert(mparts, string.format("%s|cffAAAAAA/%d %s|r",
                    met and string.format("|cff00FF00%d", have)
                        or  string.format("|cffFF4444%d", have), req, bg))
            end
            table.sort(mparts)
            row.marksFS:SetText(table.concat(mparts, "  "))
            local hc = honorMet and "00FF00" or "FF4444"
            row.honorFS:SetText(string.format("|cff%s%s|r|cffAAAAAA/%s|r", hc, fmt(honor), fmt(gear.honor)))
            row.statusFS:SetText(honorMet and allMet and "|cff00FF00Ready!|r" or "|cffAAAAAA...|r")
        end
    end

    honorFrame:SetScript("OnShow", RefreshHonorFrame)
    BeanArena_RefreshHonorFrame = RefreshHonorFrame
end




-- ============================================================
-- FORWARD DECLARATION ASSIGNMENT
-- ============================================================
OpenBeanArena = function()
    frame:Show(); BeanArena_RefreshFrame()
end

-- ============================================================
-- COMMANDS FRAME  (updated to /ba)
-- ============================================================
local COMMANDS_LIST = {
    { cmd="/ba",                desc="Toggle main window"              },
    { cmd="/ba calc [rating]",  desc="AP for live ratings or a number" },
    { cmd="/ba target <ap>",   desc="Rating needed to earn that AP"   },
    { cmd="/ba honor [slot]",   desc="Honor window or gear slot info"  },
    { cmd="/ba arena [slot]",   desc="Arena gear window or slot info"  },
    { cmd="/ba dr [class]",     desc="CC/DR window or class CC list"   },
    { cmd="/ba gear",           desc="Arena gear costs window"         },
    { cmd="/ba hgear",          desc="Honor gear costs window"         },
    { cmd="/ba info",           desc="Info window"                     },
    { cmd="/ba chars",          desc="Character viewer"                },
    { cmd="/ba alts",              desc="Print all alt PvP snapshots to chat"  },
    { cmd="/ba points",            desc="Live rating AP breakdown"              },
    { cmd="/ba marks",          desc="Current BG mark counts"          },
    { cmd="/ba reset",          desc="Time until weekly reset"         },
    { cmd="/ba commands",       desc="This window"                     },
    { cmd="/ba help",           desc="Print all commands to chat"      },
}

cFrame = MakeBGFrame("BeanArenaCommandsFrame", UIParent, 340, 42 + #COMMANDS_LIST * 24)
cFrame:SetFrameStrata("HIGH")
cFrame:SetMovable(true); cFrame:EnableMouse(true)
cFrame:RegisterForDrag("LeftButton")
cFrame:SetScript("OnDragStart", cFrame.StartMoving)
cFrame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
cFrame:Hide(); RegisterEsc(cFrame)

local cTitle = cFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
cTitle:SetPoint("TOP", cFrame, "TOP", 0, -14)
cTitle:SetText("|cffFFD700BeanArena Commands|r")

local cClose = CreateFrame("Button", nil, cFrame, "UIPanelCloseButton")
cClose:SetPoint("TOPRIGHT", cFrame, "TOPRIGHT", -4, -4)
cClose:SetScript("OnClick", function() cFrame:Hide() end)

for i, entry in ipairs(COMMANDS_LIST) do
    local y = -38 - (i - 1) * 24
    if i > 1 then
        local div = cFrame:CreateTexture(nil, "ARTWORK")
        div:SetSize(304, 1); div:SetPoint("TOPLEFT", cFrame, "TOPLEFT", 18, y + 5)
        div:SetColorTexture(0.3, 0.3, 0.3, 0.3)
    end
    local cmdFS = cFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    cmdFS:SetPoint("TOPLEFT", cFrame, "TOPLEFT", 18, y)
    cmdFS:SetText("|cff00CCFF" .. entry.cmd .. "|r")
    local descFS = cFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    descFS:SetPoint("TOPLEFT", cFrame, "TOPLEFT", 160, y)
    descFS:SetText("|cffAAAAAA" .. entry.desc .. "|r")
end

local aliasFS = cFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
aliasFS:SetPoint("BOTTOMLEFT", cFrame, "BOTTOMLEFT", 18, 10)
aliasFS:SetText("|cff888888/beanarena also works in place of /ba|r")

OpenCommands = function()
    if cFrame:IsShown() then cFrame:Hide(); return end
    cFrame:ClearAllPoints()
    cFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    cFrame:Show()
end



-- ============================================================
-- CHARACTER VIEWER FRAME  ( /ba chars )
-- ============================================================
do
    local CVW, CVH = 500, 460
    charViewFrame = MakeBGFrame("BeanArenaCharViewFrame", UIParent, CVW, CVH)
    charViewFrame:SetFrameStrata("HIGH")
    charViewFrame:SetMovable(true); charViewFrame:EnableMouse(true)
    charViewFrame:RegisterForDrag("LeftButton")
    charViewFrame:SetScript("OnDragStart", charViewFrame.StartMoving)
    charViewFrame:SetScript("OnDragStop", function(s) s:StopMovingOrSizing() end)
    charViewFrame:Hide(); RegisterEsc(charViewFrame)

    local cvClose = CreateFrame("Button", nil, charViewFrame, "UIPanelCloseButton")
    cvClose:SetPoint("TOPRIGHT", charViewFrame, "TOPRIGHT", -4, -4)
    cvClose:SetScript("OnClick", function() charViewFrame:Hide() end)

    local cvTitle = charViewFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    cvTitle:SetPoint("TOP", charViewFrame, "TOP", 0, -12)
    cvTitle:SetText("|cffFFD700Character Viewer|r")

    local cvSub = charViewFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    cvSub:SetPoint("TOP", charViewFrame, "TOP", 0, -28)
    cvSub:SetText("|cff888888Characters seen with BeanArena installed|r")

    MakeLine(charViewFrame, -40, CVW - 32, 14)

    -- Left panel: character list
    local LIST_W = 150
    local listScr = CreateFrame("ScrollFrame", "BeanArenaCharListScr", charViewFrame, "UIPanelScrollFrameTemplate")
    listScr:SetPoint("TOPLEFT",     charViewFrame, "TOPLEFT",  10, -48)
    listScr:SetPoint("BOTTOMRIGHT", charViewFrame, "TOPLEFT", LIST_W + 10, 10)
    local listCnt = CreateFrame("Frame", nil, listScr)
    listCnt:SetWidth(LIST_W - 22)
    listCnt:SetHeight(10)
    listScr:SetScrollChild(listCnt)

    -- Vertical divider
    local vdiv = charViewFrame:CreateTexture(nil, "ARTWORK")
    vdiv:SetSize(1, CVH - 60)
    vdiv:SetPoint("TOPLEFT", charViewFrame, "TOPLEFT", LIST_W + 14, -48)
    vdiv:SetColorTexture(0.3, 0.3, 0.3, 0.6)

    -- Right panel: selected character data
    local detailScr = CreateFrame("ScrollFrame", "BeanArenaCharDetailScr", charViewFrame, "UIPanelScrollFrameTemplate")
    detailScr:SetPoint("TOPLEFT",     charViewFrame, "TOPLEFT",  LIST_W + 18, -48)
    detailScr:SetPoint("BOTTOMRIGHT", charViewFrame, "BOTTOMRIGHT", -28, 10)
    local detailCnt = CreateFrame("Frame", nil, detailScr)
    detailCnt:SetWidth(CVW - LIST_W - 60)
    detailCnt:SetHeight(10)
    detailScr:SetScrollChild(detailCnt)

    local function ClearDetail()
        for _, child in ipairs({detailCnt:GetChildren()}) do child:Hide() end
        for _, r in ipairs({detailCnt:GetRegions()}) do r:Hide() end
    end

    local function BuildDetail(snap)
        ClearDetail()
        local dy = -4
        local DW = detailCnt:GetWidth()

        local function DLine(text, color, indent)
            local fs = detailCnt:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            fs:SetPoint("TOPLEFT", detailCnt, "TOPLEFT", (indent or 0), dy)
            fs:SetWidth(DW)
            fs:SetJustifyH("LEFT")
            fs:SetText("|cff" .. (color or "CCCCCC") .. text .. "|r")
            dy = dy - 14
        end
        local function DGap() dy = dy - 6 end

        DLine((snap.name or "Unknown") .. "  —  " .. (snap.realm or "?"), "FFD700")
        local ts = snap.timestamp and date("%Y-%m-%d", snap.timestamp) or "unknown"
        DLine("Last seen: " .. ts, "888888")
        DGap()
        DLine("Arena Points:  " .. (snap.arenaPoints or "?"), "88FF88")
        DLine("Honor:         " .. (snap.honor or "?"),        "88CCFF")
        DGap()

        detailCnt:SetHeight(math.abs(dy) + 20)
    end

    local function RefreshCharList()
        -- Hide old buttons
        for _, child in ipairs({listCnt:GetChildren()}) do child:Hide() end

        local chars = BeanArenaDB.chars or {}
        local rows = {}
        for key, snap in pairs(chars) do
            if type(snap) == "table" and snap.name then
                rows[#rows+1] = snap
            end
        end
        table.sort(rows, function(a,b) return (a.name or "") < (b.name or "") end)

        local ly = 0
        if #rows == 0 then
            local noFS = listCnt:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            noFS:SetPoint("TOPLEFT", listCnt, "TOPLEFT", 4, ly)
            noFS:SetText("|cff666666No characters\nfound yet.|r")
            listCnt:SetHeight(40)
            return
        end

        for i, snap in ipairs(rows) do
            local btn = CreateFrame("Button", nil, listCnt)
            btn:SetSize(listCnt:GetWidth(), 20)
            btn:SetPoint("TOPLEFT", listCnt, "TOPLEFT", 0, ly)
            btn:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square")

            local isMe = (snap.name == CHAR_NAME and snap.realm == CHAR_REALM)
            local nameFS = btn:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            nameFS:SetPoint("LEFT", btn, "LEFT", 4, 0)
            nameFS:SetWidth(listCnt:GetWidth() - 8)
            nameFS:SetText(isMe and ("|cffFFD700" .. snap.name .. "|r") or snap.name)

            btn:SetScript("OnClick", function()
                if isMe then SnapshotCharData() end
                BuildDetail(snap)
            end)

            ly = ly - 22
        end
        listCnt:SetHeight(math.abs(ly) + 10)

        -- Auto-select first
        if #rows > 0 then BuildDetail(rows[1]) end
    end

    charViewFrame:SetScript("OnShow", RefreshCharList)
end

-- ============================================================
-- REFRESH FUNCTIONS
-- ============================================================
BeanArena_RefreshManual = function()
    local m2, m3, m5 = DB("manual2v2"), DB("manual3v3"), DB("manual5v5")
    local function FmtPts(r, bracket)
        return r > 0
            and string.format("|cffFFD700%.0f|r", CalcBracketPoints(r, bracket))
            or  "|cff666666--|r"
    end
    manResultFS["2v2"]:SetText(FmtPts(m2, "2v2"))
    manResultFS["3v3"]:SetText(FmtPts(m3, "3v3"))
    manResultFS["5v5"]:SetText(FmtPts(m5, "5v5"))
    RefreshTargetCalc()
end

local function RefreshLive()
    local r2,r3,r5,g2,g3,g5 = GetLiveRatings()
    local curAP = GetCurrentArenaPoints()
    local function GT(g)
        return g >= 10 and string.format("|cff00FF00%d|r", g)
                       or  string.format("|cffFF4444%d/10|r", g)
    end
    local function ProjAP(r, b)
        return r > 0 and CalcBracketPoints(r, b) or 0
    end
    local function APTxt(ap)
        return ap > 0 and string.format("|cffFFD700%.0f|r", ap) or "|cff666666--|r"
    end
    local ap2 = ProjAP(r2, "2v2")
    local ap3 = ProjAP(r3, "3v3")
    local ap5 = ProjAP(r5, "5v5")
    liveR2:SetText(r2>0 and tostring(r2) or "|cff666666--|r")
    liveG2:SetText(GT(g2)); liveP2:SetText(APTxt(ap2))
    liveT2:SetText(ap2>0 and string.format("|cff88FF88%.0f|r", curAP+ap2) or "|cff666666--|r")
    liveR3:SetText(r3>0 and tostring(r3) or "|cff666666--|r")
    liveG3:SetText(GT(g3)); liveP3:SetText(APTxt(ap3))
    liveT3:SetText(ap3>0 and string.format("|cff88FF88%.0f|r", curAP+ap3) or "|cff666666--|r")
    liveR5:SetText(r5>0 and tostring(r5) or "|cff666666--|r")
    liveG5:SetText(GT(g5)); liveP5:SetText(APTxt(ap5))
    liveT5:SetText(ap5>0 and string.format("|cff88FF88%.0f|r", curAP+ap5) or "|cff666666--|r")
    apInlineVal:SetText(curAP > 0
        and string.format("|cff88FF88%d|r", curAP)
        or  "|cff666666--|r")
end

local function RefreshMisc()
    if refFrame:IsShown()   then BeanArena_RefreshRefFrame()    end
    if honorFrame:IsShown() and BeanArena_RefreshHonorFrame then
        BeanArena_RefreshHonorFrame()
    end
end

BeanArena_RefreshFrame = function()
    if viewingSnap == nil then RefreshLive() end; RefreshMisc()
    if not editFocused["manual2v2"] then man2v2Edit:SetText(tostring(DB("manual2v2"))) end
    if not editFocused["manual3v3"] then man3v3Edit:SetText(tostring(DB("manual3v3"))) end
    if not editFocused["manual5v5"] then man5v5Edit:SetText(tostring(DB("manual5v5"))) end
    if not editFocused["targetAP"] then
        local v = DB("targetAP"); targetAPEdit:SetText(v > 0 and tostring(v) or "")
    end
    BeanArena_RefreshManual()
end

-- ============================================================
-- DR DATA  (TBC 2.4.3 / Anniversary)
-- ============================================================
local DR_CATEGORIES = {
    { id="STUN_CTRL", name="Controlled Stun",  color="FF4444", desc="Activated stun abilities. Full→50%→25%→immune." },
    { id="STUN_KS",   name="Kidney Shot",       color="FF6622", desc="Kidney Shot only. Its own independent DR." },
    { id="STUN_PROC", name="Proc Stun",         color="FF8844", desc="Stun procs from talents/items." },
    { id="INCAP",     name="Incapacitate",      color="FFD700", desc="Breaks on damage. Polymorph, Sap, Gouge, etc." },
    { id="FEAR",      name="Fear / Disorient",  color="CC88FF", desc="Running fears + Blind (TBC: Blind shares Fear DR)." },
    { id="HORROR",    name="Horror",            color="AA44FF", desc="Death Coil. Own category, not Fear." },
    { id="CYCLONE",   name="Cyclone",           color="00CCFF", desc="DRs with itself only in TBC." },
    { id="ROOT_CTRL", name="Controlled Root",   color="00FF88", desc="Frost Nova, Entangling Roots, Freeze, Frostbite." },
    { id="SLEEP",     name="Sleep / Hibernate", color="88FFCC", desc="Wyvern Sting, Hibernate (breaks on dmg)." },
    { id="SILENCE",   name="Silence",           color="AAAAAA", desc="NO DR in TBC. Chain freely." },
    { id="DISARM",    name="Disarm",            color="FFAA44", desc="Subject to DR in PvP." },
}

local CLASS_CC = {
    -- dur format: "Xs" = no DR, "Xs/Ys/Zs" = full/50%/25% (immune after 3rd)
    ["Druid"]   = {
        { spell="Cyclone",            dr="CYCLONE",   dur="6s/3s/1.5s", notes="Immunity, no dmg/heal" },
        { spell="Bash",               dr="STUN_CTRL", dur="3s/1.5s/0.75s", notes="Bear form" },
        { spell="Pounce",             dr="STUN_CTRL", dur="3s/1.5s/0.75s", notes="Cat stealth opener" },
        { spell="Maim",               dr="STUN_CTRL", dur="5s/2.5s/1s",    notes="Cat finisher (5cp)" },
        { spell="Hibernate",          dr="SLEEP",     dur="8s/4s/2s",  notes="Beasts/Dragonkin" },
        { spell="Entangling Roots",   dr="ROOT_CTRL", dur="8s/4s/2s",  notes="Breaks on dmg" },
        { spell="Nature's Grasp",     dr="ROOT_CTRL", dur="8s/4s/2s",  notes="Proc root on hit" },
        { spell="Feral Charge",       dr="ROOT_CTRL", dur="4s/2s/1s",  notes="Bear interrupt+root" },
    },
    ["Hunter"]  = {
        { spell="Freezing Trap",  dr="INCAP",     dur="8s/4s/2s",   notes="Target walks in" },
        { spell="Wyvern Sting",   dr="SLEEP",     dur="8s/4s/2s",   notes="Survival, 1 min CD" },
        { spell="Scatter Shot",   dr="FEAR",      dur="4s/2s/1s",   notes="Breaks on dmg" },
        { spell="Intimidation",   dr="STUN_CTRL", dur="3s/1.5s/0.75s", notes="Pet, BM talent" },
        { spell="Silencing Shot", dr="SILENCE",   dur="3s",         notes="NO DR in TBC" },
        { spell="Entrapment",     dr="ROOT_CTRL", dur="4s/2s/1s",   notes="Frost Trap proc" },
        { spell="Scare Beast",    dr="FEAR",      dur="8s/4s/2s",   notes="Beasts only" },
    },
    ["Mage"]    = {
        { spell="Polymorph",         dr="INCAP",     dur="8s/4s/2s", notes="Humanoids, heals target" },
        { spell="Frost Nova",        dr="ROOT_CTRL", dur="8s/4s/2s", notes="Melee AoE" },
        { spell="Freeze",            dr="ROOT_CTRL", dur="8s/4s/2s", notes="Water Elemental" },
        { spell="Frostbite",         dr="ROOT_CTRL", dur="5s/2.5s/1s", notes="Chill proc, 2.1+" },
        { spell="Dragon's Breath",   dr="INCAP",     dur="5s/2.5s/1s", notes="Fire 41pt, breaks on dmg" },
        { spell="Counterspell",      dr="SILENCE",   dur="8s",       notes="Interrupt+lock; NO DR" },
        { spell="Imp. Counterspell", dr="SILENCE",   dur="4s",       notes="Silence; NO DR" },
    },
    ["Paladin"] = {
        { spell="Hammer of Justice", dr="STUN_CTRL", dur="6s/3s/1.5s", notes="Any target" },
        { spell="Repentance",        dr="INCAP",     dur="6s/3s/1.5s", notes="Humanoids/Undead/Demons" },
        { spell="Turn Evil",         dr="FEAR",      dur="10s/5s/2.5s", notes="Undead/Demons" },
    },
    ["Priest"]  = {
        { spell="Psychic Scream",   dr="FEAR",    dur="8s/4s/2s", notes="AoE fear" },
        { spell="Mind Control",     dr="NONE",    dur="—",        notes="No DR; breaks on dmg" },
        { spell="Shackle Undead",   dr="NONE",    dur="50s",      notes="Undead only; no DR" },
        { spell="Silence (Shadow)", dr="SILENCE", dur="5s",       notes="Shadow spec; NO DR" },
    },
    ["Rogue"]   = {
        { spell="Sap",         dr="INCAP",     dur="10s/5s/2.5s", notes="OOC; breaks on dmg" },
        { spell="Gouge",       dr="INCAP",     dur="4s/2s/1s",    notes="Breaks on dmg" },
        { spell="Cheap Shot",  dr="STUN_CTRL", dur="4s/2s/1s",    notes="Stealth opener" },
        { spell="Kidney Shot", dr="STUN_KS",   dur="6s/3s/1.5s",  notes="5cp; own DR" },
        { spell="Blind",       dr="FEAR",      dur="10s/5s/2.5s", notes="Shares Fear DR in TBC" },
        { spell="Garrote",     dr="SILENCE",   dur="3s",          notes="Stealth silence; NO DR" },
    },
    ["Shaman"]  = {
        { spell="Earthbind Totem",   dr="NONE",    dur="—",  notes="Slow pulse; no DR" },
        { spell="Frost Shock",       dr="NONE",    dur="8s", notes="Snare only; no DR" },
        { spell="Earth Shock",       dr="SILENCE", dur="2s", notes="Interrupt; NO DR" },
        { spell="Frostbrand Weapon", dr="NONE",    dur="5s", notes="Snare proc; no DR" },
    },
    ["Warlock"] = {
        { spell="Fear",           dr="FEAR",      dur="8s/4s/2s",   notes="Breaks on dmg" },
        { spell="Howl of Terror", dr="FEAR",      dur="8s/4s/2s",   notes="AoE; breaks on dmg" },
        { spell="Death Coil",     dr="HORROR",    dur="3s/1.5s/0.75s", notes="Horror category" },
        { spell="Seduction",      dr="FEAR",      dur="15s/7.5s/3.75s", notes="Succubus; humanoids" },
        { spell="Shadowfury",     dr="STUN_CTRL", dur="3s/1.5s/0.75s", notes="Destro 41pt AoE" },
        { spell="Spell Lock",     dr="SILENCE",   dur="3s",         notes="Felhunter; NO DR" },
        { spell="Banish",         dr="NONE",      dur="30s",        notes="Demons/Elementals; no DR" },
    },
    ["Warrior"] = {
        { spell="Intimidating Shout", dr="FEAR",      dur="8s/4s/2s",      notes="AoE; primary immob." },
        { spell="Intercept",          dr="STUN_CTRL", dur="3s/1.5s/0.75s", notes="Charge stun" },
        { spell="Concussion Blow",    dr="STUN_CTRL", dur="5s/2.5s/1s",    notes="Prot talent" },
        { spell="Hamstring",          dr="NONE",      dur="15s", notes="Snare; no DR" },
        { spell="Disarm",             dr="DISARM",    dur="10s", notes="Weapon disarm" },
        { spell="Mace Stun Proc",     dr="STUN_PROC", dur="3s",  notes="Mace Spec proc" },
    },
}

local function BuildDRCrossRef()
    local tbl = {}
    for cls, spells in pairs(CLASS_CC) do
        for _, entry in ipairs(spells) do
            local dr = entry.dr
            if dr ~= "NONE" then
                if not tbl[dr] then tbl[dr] = {} end
                table.insert(tbl[dr], { class=cls, spell=entry.spell, dur=entry.dur })
            end
        end
    end
    for dr, entries in pairs(tbl) do
        table.sort(entries, function(a,b) return a.class < b.class end)
    end
    return tbl
end

-- ============================================================
-- POPUP: UNIFIED REFERENCE FRAME
-- Arena Gear / Weapons / Honor Gear / CC/DR Table / Info
-- ============================================================
do
    local RF_W = 500
    local RF_H = 560
    local RCW  = RF_W - 52   -- 448 px content width

    refFrame = MakeBGFrame("BeanArenaRefFrame", UIParent, RF_W, RF_H)
    refFrame:SetFrameStrata("HIGH")
    refFrame:SetMovable(true); refFrame:EnableMouse(true)
    refFrame:RegisterForDrag("LeftButton")
    refFrame:SetScript("OnDragStart", refFrame.StartMoving)
    refFrame:SetScript("OnDragStop", function(s) s:StopMovingOrSizing() end)
    refFrame:Hide(); RegisterEsc(refFrame)

    local rfTitleFS = refFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    rfTitleFS:SetPoint("TOP", refFrame, "TOP", 0, -12)
    rfTitleFS:SetText("|cffFFD700Reference|r")

    local rfClose = CreateFrame("Button", nil, refFrame, "UIPanelCloseButton")
    rfClose:SetPoint("TOPRIGHT", refFrame, "TOPRIGHT", -4, -4)
    rfClose:SetScript("OnClick", function() refFrame:Hide() end)

    -- Section selector (dropdown button + hidden anchor)
    local rfSection = "Arena Gear"
    local RF_SECTIONS = {"Arena Gear", "Weapons", "Honor Gear", "CC/DR Table", "Info"}
    local rfSectBtn = CreateFrame("Button", nil, refFrame, "UIPanelButtonTemplate")
    rfSectBtn:SetSize(158, 22)
    rfSectBtn:SetPoint("TOPLEFT", refFrame, "TOPLEFT", 12, -32)
    rfSectBtn:GetFontString():SetFontObject("GameFontNormalSmall")
    rfSectBtn:SetText("Arena Gear  v")
    local rfSectDD = CreateFrame("Frame", "BeanArenaRfSectDD", UIParent, "UIDropDownMenuTemplate")

    -- Season toggle (hidden for CC/DR Table and Info)
    local rfSeason = 2
    local rfS1Btn = CreateFrame("Button", nil, refFrame, "UIPanelButtonTemplate")
    rfS1Btn:SetSize(48, 22)
    rfS1Btn:SetPoint("LEFT", rfSectBtn, "RIGHT", 6, 0)
    rfS1Btn:SetText("S1"); rfS1Btn:GetFontString():SetFontObject("GameFontNormalSmall")
    local rfS2Btn = CreateFrame("Button", nil, refFrame, "UIPanelButtonTemplate")
    rfS2Btn:SetSize(48, 22)
    rfS2Btn:SetPoint("LEFT", rfS1Btn, "RIGHT", 4, 0)
    rfS2Btn:SetText("S2"); rfS2Btn:GetFontString():SetFontObject("GameFontNormalSmall")

    -- Class dropdown (visible for Arena Gear only)
    local rfClass = "Warrior"
    local rfClassBtn = CreateFrame("Button", nil, refFrame, "UIPanelButtonTemplate")
    rfClassBtn:SetSize(138, 22)
    rfClassBtn:SetPoint("LEFT", rfS2Btn, "RIGHT", 6, 0)
    rfClassBtn:GetFontString():SetFontObject("GameFontNormalSmall")
    rfClassBtn:SetText("Warrior  v")
    local rfClassDD = CreateFrame("Frame", "BeanArenaRfClassDD", UIParent, "UIDropDownMenuTemplate")

    -- Scroll area
    local rfScr = CreateFrame("ScrollFrame", "BeanArenaRfScr", refFrame, "UIPanelScrollFrameTemplate")
    rfScr:SetPoint("TOPLEFT",     refFrame, "TOPLEFT",     10, -62)
    rfScr:SetPoint("BOTTOMRIGHT", refFrame, "BOTTOMRIGHT", -28, 10)
    local rfCnt = CreateFrame("Frame", nil, rfScr)
    rfCnt:SetWidth(RCW)
    rfCnt:SetHeight(10)
    rfScr:SetScrollChild(rfCnt)

    local function ClearContent()
        for _, ch in ipairs({rfCnt:GetChildren()}) do ch:Hide() end
        for _, r  in ipairs({rfCnt:GetRegions()})  do r:Hide()  end
    end

    local SwitchSection  -- forward decl

    -- ================================================================
    -- ARENA GEAR
    -- ================================================================
    local SL_W    = 68
    local IC_SZ   = 40
    local IC_CELL = 44
    local SLOT_DEFS = {
        {slot="Head",      apS1=1375, apS2=1550, rating=0   },
        {slot="Chest",     apS1=1375, apS2=1550, rating=0   },
        {slot="Legs",      apS1=1375, apS2=1550, rating=0   },
        {slot="Gloves",    apS1=875,  apS2=930,  rating=0   },
        {slot="Shoulders", apS1=1125, apS2=1245, rating=2000},
    }
    local EQUIP_TO_SLOT = {
        INVTYPE_HEAD     = "Head",
        INVTYPE_SHOULDER = "Shoulders",
        INVTYPE_CHEST    = "Chest",
        INVTYPE_ROBE     = "Chest",
        INVTYPE_LEGS     = "Legs",
        INVTYPE_HAND     = "Gloves",
    }

    local function BuildArenaContent()
        ClearContent()
        local setList    = rfSeason == 2 and CLASS_SETS_S2 or CLASS_SETS_S1
        local r2,r3,r5   = GetLiveRatings()
        local bestRating = math.max(r2, r3, r5)
        local curAP      = GetCurrentArenaPoints()
        local cy = -2

        local function AGLine()
            local d = rfCnt:CreateTexture(nil,"ARTWORK")
            d:SetSize(RCW,1); d:SetPoint("TOPLEFT",rfCnt,"TOPLEFT",0,cy-2)
            d:SetColorTexture(0.3,0.3,0.3,0.5); cy=cy-8
        end
        local function AGHdr(txt)
            local h = rfCnt:CreateFontString(nil,"OVERLAY","GameFontNormal")
            h:SetPoint("TOPLEFT",rfCnt,"TOPLEFT",0,cy)
            h:SetText("|cff00CCFF"..txt.."|r"); cy=cy-16
        end

        local variants = setList[rfClass] or {rfClass.." Set"}
        local nV = #variants
        AGHdr(string.format("Armor Set  |cffAAAAAA— %s  (%d variant%s)|r",
            rfClass, nV, nV > 1 and "s" or ""))
        if nV > 1 then
            local vLine = ""
            for vi, varName in ipairs(variants) do
                local tail = varName:match("(%S+)$") or varName
                vLine = vLine .. (vi > 1 and "  |  " or "") .. vi .. ":" .. tail
            end
            local vLbl = rfCnt:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            vLbl:SetPoint("TOPLEFT", rfCnt,"TOPLEFT", 0, cy)
            vLbl:SetWidth(RCW)
            vLbl:SetText("|cff888888Cols: " .. vLine .. "|r")
            cy = cy - 14
        end
        AGLine(); cy = cy - 4

        local slotGrid = {}
        for vi, varName in ipairs(variants) do
            slotGrid[vi] = {}
            for _, id in ipairs(ARMOR_SET_IDS[varName] or {}) do
                local _, _, _, _, _, _, _, _, equipLoc = GetItemInfo(id)
                if equipLoc and equipLoc ~= "" then
                    local sn = EQUIP_TO_SLOT[equipLoc]
                    if sn then slotGrid[vi][sn] = id end
                end
            end
        end

        for _, def in ipairs(SLOT_DEFS) do
            local slotName = def.slot
            local sLbl = rfCnt:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            sLbl:SetPoint("TOPLEFT", rfCnt,"TOPLEFT", 0, cy - 13)
            sLbl:SetText("|cffAAAAAA"..slotName.."|r")
            for vi = 1, nV do
                local itemID  = slotGrid[vi] and slotGrid[vi][slotName]
                local iconPath
                if itemID then
                    local _, _, _, _, _, _, _, _, _, tex = GetItemInfo(itemID)
                    iconPath = tex
                end
                local iconBtn = CreateFrame("Button", nil, rfCnt)
                iconBtn:SetSize(IC_SZ, IC_SZ)
                iconBtn:SetPoint("TOPLEFT", rfCnt,"TOPLEFT", SL_W + (vi-1)*IC_CELL, cy)
                local bg = iconBtn:CreateTexture(nil,"BACKGROUND")
                bg:SetAllPoints(); bg:SetColorTexture(0.10, 0.10, 0.12, 1)
                local iconTex = iconBtn:CreateTexture(nil,"ARTWORK")
                iconTex:SetAllPoints()
                iconTex:SetTexture(iconPath or "Interface\Icons\INV_Misc_QuestionMark")
                iconBtn:SetHighlightTexture("Interface\Buttons\ButtonHilight-Square")
                if itemID then
                    local capID = itemID
                    iconBtn:SetScript("OnEnter", function(self)
                        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                        GameTooltip:SetHyperlink("item:"..capID)
                        GameTooltip:Show()
                    end)
                    iconBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
                end
            end
            cy = cy - (IC_SZ + 4)
        end

        cy = cy - 4; AGLine(); cy = cy - 4
        local costHdr = rfCnt:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        costHdr:SetPoint("TOPLEFT", rfCnt,"TOPLEFT", 0, cy)
        costHdr:SetText("|cff888888Costs (S"..rfSeason.."):|r")
        cy = cy - 15
        for _, def in ipairs(SLOT_DEFS) do
            local ap     = rfSeason == 2 and def.apS2 or def.apS1
            local rating = def.rating
            local rMet   = rating == 0 or bestRating >= rating
            local aMet   = curAP >= ap
            local allMet = aMet and rMet
            local cLbl = rfCnt:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            cLbl:SetPoint("TOPLEFT", rfCnt,"TOPLEFT", 0, cy)
            cLbl:SetText("|cffAAAAAA"..def.slot.."|r")
            local apLbl = rfCnt:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            apLbl:SetPoint("TOPLEFT", rfCnt,"TOPLEFT", 82, cy)
            apLbl:SetText(string.format("|cff%s%d AP|r", aMet and "FFD700" or "FF6666", ap))
            if rating > 0 then
                local rLbl = rfCnt:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
                rLbl:SetPoint("TOPLEFT", rfCnt,"TOPLEFT", 155, cy)
                rLbl:SetText(string.format("|cff%s%d rating|r",
                    rMet and "00FF00" or "FF4444", rating))
            end
            local tick = rfCnt:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            tick:SetPoint("TOPRIGHT", rfCnt,"TOPRIGHT", 0, cy)
            tick:SetText(allMet and "|cff00FF00[OK]|r" or
                         (not aMet and "|cffFF4444[NO]|r" or "|cffFFAA00[!]|r"))
            cy = cy - 16
        end
        rfCnt:SetHeight(math.abs(cy) + 20)
    end

    -- ================================================================
    -- WEAPONS
    -- ================================================================
    local WICON    = 36
    local WCELL_W  = WICON + 4
    local WPER_ROW = math.floor(RCW / (WICON + 4))
    local WEAPON_GROUPS = {
        { label="1H Weapons",          keys={"1H-Dagger","1H-Sword","1H-Mace","1H-Axe","1H-Fist","1H-SwordCaster","1H-MaceHeal"} },
        { label="2H Weapons",          keys={"2H-Sword","2H-Axe","2H-Mace","2H-Polearm","2H-Staff","2H-StaffFeral"} },
        { label="Ranged & Wands",      keys={"Crossbow","Thrown","Wand"} },
        { label="Shields & Off-hands", keys={"Shield","Off-Tome","Off-Orb"} },
        { label="Relics",              keys={"Idol","Libram","Totem"} },
    }

    local function BuildWeaponsContent()
        ClearContent()
        local weaponList = rfSeason == 2 and S2_WEAPONS or S1_WEAPONS
        local r2,r3,r5   = GetLiveRatings()
        local bestRating = math.max(r2, r3, r5)
        local curAP      = GetCurrentArenaPoints()
        local cy = -2
        local function WHdr(txt)
            local h = rfCnt:CreateFontString(nil,"OVERLAY","GameFontNormal")
            h:SetPoint("TOPLEFT",rfCnt,"TOPLEFT",0,cy)
            h:SetText("|cff00CCFF"..txt.."|r"); cy=cy-18
        end
        local function WLine()
            local d = rfCnt:CreateTexture(nil,"ARTWORK")
            d:SetSize(RCW,1); d:SetPoint("TOPLEFT",rfCnt,"TOPLEFT",0,cy-2)
            d:SetColorTexture(0.3,0.3,0.3,0.5); cy=cy-7
        end
        local byKey = {}
        for _, wep in ipairs(weaponList) do
            if not byKey[wep.key] then byKey[wep.key] = {} end
            byKey[wep.key][#byKey[wep.key]+1] = wep
        end
        for _, grp in ipairs(WEAPON_GROUPS) do
            local items = {}
            for _, k in ipairs(grp.keys) do
                for _, wep in ipairs(byKey[k] or {}) do
                    for _, id in ipairs(wep.ids or {}) do
                        items[#items+1] = {id=id, wep=wep}
                    end
                end
            end
            if #items > 0 then
                WHdr(grp.label.."  |cffAAAAAA("..#items.." item"..(#items~=1 and "s" or "")..")|r")
                WLine()
                local col  = 0
                local rowY = cy - 4
                for _, itm in ipairs(items) do
                    local id        = itm.id
                    local wep       = itm.wep
                    local canAfford = curAP >= wep.ap
                    local ratingMet = wep.rating == 0 or bestRating >= wep.rating
                    local iconBtn = CreateFrame("Button", nil, rfCnt)
                    iconBtn:SetSize(WICON, WICON)
                    iconBtn:SetPoint("TOPLEFT", rfCnt, "TOPLEFT", col * WCELL_W, rowY)
                    local iconTex = iconBtn:CreateTexture(nil, "BACKGROUND")
                    iconTex:SetAllPoints()
                    local _,_,_,_,_,_,_,_,_,iconPath = GetItemInfo(id)
                    iconTex:SetTexture(iconPath or "Interface\Icons\INV_Misc_QuestionMark")
                    if not (canAfford and ratingMet) then
                        iconTex:SetDesaturated(true); iconTex:SetVertexColor(0.55, 0.55, 0.55)
                    end
                    iconBtn:SetHighlightTexture("Interface\Buttons\ButtonHilight-Square")
                    local capID, capWep, capCA, capRM = id, wep, canAfford, ratingMet
                    iconBtn:SetScript("OnEnter", function(self)
                        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                        GameTooltip:SetHyperlink("item:"..capID)
                        GameTooltip:AddLine(" ")
                        GameTooltip:AddLine(string.format("|cff%s%d Arena Points|r",
                            capCA and "FFD700" or "FF6666", capWep.ap))
                        if capWep.rating > 0 then
                            GameTooltip:AddLine(string.format("|cff%sRequires %d Rating|r",
                                capRM and "00FF00" or "FF4444", capWep.rating))
                        else
                            GameTooltip:AddLine("|cff00FF00No Rating Requirement|r")
                        end
                        GameTooltip:Show()
                    end)
                    iconBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
                    col = col + 1
                    if col >= WPER_ROW then col = 0; rowY = rowY - WCELL_W end
                end
                if col > 0 then rowY = rowY - WCELL_W end
                cy = rowY - 6
            end
        end
        rfCnt:SetHeight(math.abs(cy) + 20)
    end

    -- ================================================================
    -- HONOR GEAR  (class auto-detected, no manual switcher)
    -- ================================================================
    local HICON = 20

    local function BuildHonorContent()
        ClearContent()
        local armorType  = CLASS_ARMOR_TYPE[rfClass] or "Cloth"
        local universal  = rfSeason == 2 and S2_HONOR_UNIVERSAL or S1_HONOR_UNIVERSAL
        local byArmor    = rfSeason == 2 and S2_HONOR_BYARMOR   or S1_HONOR_BYARMOR
        local armorRows  = byArmor[armorType] or {}
        local honor      = GetCurrentHonor()
        local marks      = GetPvPMarkCounts()
        local fmt        = BreakUpLargeNumbers or tostring
        local cy         = -2
        local HCOL = { name=HICON+2, honor=RCW-195, marks=RCW-130, have=RCW-48 }

        local function HLine()
            local d=rfCnt:CreateTexture(nil,"ARTWORK")
            d:SetSize(RCW,1); d:SetPoint("TOPLEFT",rfCnt,"TOPLEFT",0,cy-2)
            d:SetColorTexture(0.3,0.3,0.3,0.5); cy=cy-8
        end
        local function HGHdr(txt)
            local h=rfCnt:CreateFontString(nil,"OVERLAY","GameFontNormal")
            h:SetPoint("TOPLEFT",rfCnt,"TOPLEFT",0,cy)
            h:SetText("|cff00CCFF"..txt.."|r"); cy=cy-16
        end
        local function ColHdrs()
            local function CH(x,t)
                local f=rfCnt:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
                f:SetPoint("TOPLEFT",rfCnt,"TOPLEFT",x,cy); f:SetText("|cffAAAAAA"..t.."|r")
            end
            CH(HCOL.name,"Item"); CH(HCOL.honor,"Honor"); CH(HCOL.marks,"Marks"); CH(HCOL.have,"You Have")
            cy=cy-14; HLine()
        end

        local function ItemRow(item, slotData)
            local honorMet = honor >= slotData.honor
            local hCol = honorMet and "00FF00" or "FF4444"
            local allMet = true
            local mparts = {}
            for bg, req in pairs(slotData.marks) do
                local have = marks[bg] or 0
                if have < req then allMet = false end
                local mc = have >= req and "00FF00" or "FF4444"
                mparts[#mparts+1] = string.format("|cff%s%d|r|cffAAAAAA/%d %s|r", mc, have, req, bg)
            end
            if #mparts == 0 then mparts[#mparts+1] = "|cff00FF00—|r" end
            local rowBtn = CreateFrame("Button", nil, rfCnt)
            rowBtn:SetSize(RCW, HICON)
            rowBtn:SetPoint("TOPLEFT", rfCnt, "TOPLEFT", 0, cy)
            rowBtn:SetHighlightTexture("Interface\Buttons\ButtonHilight-Square")
            local iconTex = rowBtn:CreateTexture(nil, "BACKGROUND")
            iconTex:SetSize(HICON, HICON)
            iconTex:SetPoint("LEFT", rowBtn, "LEFT", 0, 0)
            local _,_,_,_,_,_,_,_,_,iconPath = GetItemInfo(item.id)
            iconTex:SetTexture(iconPath or "Interface\Icons\INV_Misc_QuestionMark")
            if not (honorMet and allMet) then
                iconTex:SetDesaturated(true); iconTex:SetVertexColor(0.55, 0.55, 0.55)
            end
            local function BFS(x, t)
                local f = rowBtn:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
                f:SetPoint("LEFT",rowBtn,"LEFT",x,0); f:SetText(t)
            end
            local dispName = item.name or ("item:"..item.id)
            local cached = GetItemInfo(item.id)
            if cached then dispName = cached end
            BFS(HCOL.name,  "|cffCCCCCC"..dispName.."|r")
            BFS(HCOL.honor, string.format("|cff%s%s|r", hCol, fmt(slotData.honor)))
            BFS(HCOL.marks, table.concat(mparts,"  "))
            BFS(HCOL.have,  (honorMet and allMet) and "|cff00FF00Ready!|r" or "|cffAAAAAA...|r")
            local capturedID = item.id
            rowBtn:SetScript("OnEnter", function(self)
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:SetHyperlink("item:"..capturedID)
                GameTooltip:Show()
            end)
            rowBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
            cy = cy - (HICON + 2)
        end

        HGHdr("Neck & Ring  |cffAAAAAA— all classes|r")
        ColHdrs()
        for _, slotData in ipairs(universal) do
            local prev_cy = cy
            for _, item in ipairs(slotData.items) do ItemRow(item, slotData) end
            if cy ~= prev_cy then cy = cy - 4 end
        end
        cy = cy - 4
        HGHdr("Off-pieces  |cffAAAAAA— "..armorType.." ("..rfClass..")|r")
        ColHdrs()
        if #armorRows == 0 then
            local nf=rfCnt:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            nf:SetPoint("TOPLEFT",rfCnt,"TOPLEFT",0,cy)
            nf:SetText("|cff666666No data for "..armorType.."|r"); cy=cy-15
        else
            for _, slotData in ipairs(armorRows) do
                local slbl=rfCnt:CreateFontString(nil,"OVERLAY","GameFontNormal")
                slbl:SetPoint("TOPLEFT",rfCnt,"TOPLEFT",0,cy)
                slbl:SetText("|cff888888— "..slotData.slot.." —|r"); cy=cy-14
                for _, item in ipairs(slotData.items) do ItemRow(item, slotData) end
                cy = cy - 4
            end
        end
        rfCnt:SetHeight(math.abs(cy)+20)
    end

    -- ================================================================
    -- CC/DR TABLE
    -- ================================================================
    local function BuildDRContent()
        ClearContent()
        local crossRef = BuildDRCrossRef()
        local cy = -4
        for _, cat in ipairs(DR_CATEGORIES) do
            local entries = crossRef[cat.id]
            local hdr = rfCnt:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            hdr:SetPoint("TOPLEFT", rfCnt, "TOPLEFT", 2, cy)
            hdr:SetText(string.format("|cff%s%s|r  |cffAAAAAA— %s|r", cat.color, cat.name, cat.desc))
            cy = cy - 15
            local div = rfCnt:CreateTexture(nil, "ARTWORK")
            div:SetSize(RCW - 8, 1); div:SetPoint("TOPLEFT", rfCnt, "TOPLEFT", 2, cy)
            div:SetColorTexture(0.3, 0.3, 0.3, 0.5); cy = cy - 5
            if not entries or #entries == 0 then
                local ne = rfCnt:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                ne:SetPoint("TOPLEFT", rfCnt, "TOPLEFT", 10, cy)
                ne:SetText("|cff555555(none)|r"); cy = cy - 14
            else
                for _, e in ipairs(entries) do
                    local ln = rfCnt:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                    ln:SetPoint("TOPLEFT", rfCnt, "TOPLEFT", 10, cy)
                    ln:SetText(string.format("|cffFFD700%-10s|r  |cffFFFFFF%-22s|r  |cffAAAAAA%s|r",
                        e.class, e.spell, e.dur))
                    cy = cy - 14
                end
            end
            cy = cy - 6
        end
        local noteDiv = rfCnt:CreateTexture(nil, "ARTWORK")
        noteDiv:SetSize(RCW - 8, 1); noteDiv:SetPoint("TOPLEFT", rfCnt, "TOPLEFT", 2, cy - 4)
        noteDiv:SetColorTexture(0.4, 0.35, 0.25, 0.6); cy = cy - 14
        local noteHdr = rfCnt:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        noteHdr:SetPoint("TOPLEFT", rfCnt, "TOPLEFT", 2, cy)
        noteHdr:SetText("|cff00CCFFTBC-Specific Rules|r"); cy = cy - 15
        local tbcNotes = {
            "|cffFFFFFFBlind|r  |cffAAAAAAshares Fear DR (not Cyclone) — changed post-TBC|r",
            "|cffFFFFFFCyclone|r  |cffAAAAAADRs with itself only in TBC|r",
            "|cffFFFFFFKidney Shot|r  |cffAAAAAAown stun DR, separate from Cheap Shot|r",
            "|cffFFFFFFSilences|r  |cffFF4444ZERO DR in TBC|r|cffAAAAAA — chain Garrote+Silence+Spell Lock freely|r",
            "|cffFFFFFFDeath Coil|r  |cffAAAAAAHorror category, NOT Fear|r",
            "|cffFFFFFFProc Stuns|r  |cffAAAAAA(Mace Spec) separate DR from activated stuns|r",
        }
        for _, note in ipairs(tbcNotes) do
            local nFS = rfCnt:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            nFS:SetPoint("TOPLEFT", rfCnt, "TOPLEFT", 10, cy)
            nFS:SetText(note); cy = cy - 14
        end
        rfCnt:SetHeight(math.abs(cy) + 20)
    end

    -- ================================================================
    -- INFO
    -- ================================================================
    local function BuildInfoContent()
        ClearContent()
        local INFO_SECTIONS = {
            { hdr="Overview", body=
                "BeanArena is a PvP utility addon for WoW TBC Anniversary. It tracks your arena ratings, arena point projections, honor, and battleground marks, and helps you plan gear purchases and understand CC/DR rules, all without leaving the game." },
            { hdr="Main Window  ( /ba )", body=
                "Shows your live 2v2 / 3v3 / 5v5 ratings, games played, and projected AP reward for the week. The Arena Point Calculator lets you type in any rating to simulate AP earnings. Banked AP is shown so you can track progress toward your next item." },
            { hdr="Honor Window  ( /ba honor )", body=
                "Displays your current honor, progress toward the 75,000 cap, weekly honor plan, BG mark inventory, and a full honor gear checklist with checkboxes to track what you still need." },
            { hdr="Reference Window  ( /ba gear  |  /ba dr  |  /ba info )", body=
                "One unified window with a dropdown to switch sections:\nArena Gear — S1/S2 armor icons + AP/rating costs\nWeapons — All weapons, relics, off-hands\nHonor Gear — S1/S2 honor costs (auto-detects class)\nCC/DR Table — All DR categories for TBC\nInfo — This guide" },
            { hdr="Character Viewer  ( /ba chars )", body=
                "View arena/honor data for your other characters. Any character that has logged in with BeanArena installed will appear here." },
            { hdr="Slash Commands", body=
                "/ba calc [#]    AP for all brackets\n/ba honor [slot] Honor gear cost+progress\n/ba arena [slot] Arena gear cost+progress\n/ba dr [class]  CC & DR for a class\n/ba gear        Reference: Arena Gear\n/ba hgear       Reference: Honor Gear\n/ba weapons     Reference: Weapons\n/ba info        Reference: Info\n/ba marks       BG mark counts\n/ba help        All commands" },
            { hdr="Tips", body=
                "BeanArena opens alongside the PvP panel (H key) automatically.\nMinimap: left-click = main window, middle-click = commands.\n/ba calc 1750 checks AP for any rating.\n/ba dr mage lists Mage DR spells.\nFrame position is saved between sessions." },
        }
        local cy = -8
        local PAD_L = 4
        for _, sec in ipairs(INFO_SECTIONS) do
            local hdrFS = rfCnt:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            hdrFS:SetPoint("TOPLEFT", rfCnt, "TOPLEFT", PAD_L, cy)
            hdrFS:SetText("|cffFFD700" .. sec.hdr .. "|r")
            cy = cy - 18
            for line in (sec.body .. "\n"):gmatch("([^\n]*)\n") do
                local bodyFS = rfCnt:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                bodyFS:SetPoint("TOPLEFT", rfCnt, "TOPLEFT", PAD_L + 6, cy)
                bodyFS:SetWidth(RCW - PAD_L - 10)
                bodyFS:SetJustifyH("LEFT")
                bodyFS:SetText("|cffCCCCCC" .. line .. "|r")
                local wrapEst = math.max(1, math.ceil(#line / 55))
                cy = cy - (14 * wrapEst)
            end
            cy = cy - 10
        end
        rfCnt:SetHeight(math.abs(cy) + 20)
    end

    -- ================================================================
    -- SwitchSection dispatcher
    -- ================================================================
    SwitchSection = function(name)
        rfSection = name
        rfSectBtn:SetText(name .. "  v")
        local hasSeasons = (name == "Arena Gear" or name == "Weapons" or name == "Honor Gear")
        if hasSeasons then rfS1Btn:Show(); rfS2Btn:Show() else rfS1Btn:Hide(); rfS2Btn:Hide() end
        if name == "Arena Gear" then rfClassBtn:Show() else rfClassBtn:Hide() end
        rfScr:SetVerticalScroll(0)
        if name == "Arena Gear" then
            BuildArenaContent()
        elseif name == "Weapons" then
            for _, wlist in ipairs({S1_WEAPONS, S2_WEAPONS}) do
                for _, wep in ipairs(wlist) do
                    if wep.ids then for _, id in ipairs(wep.ids) do GetItemInfo(id) end end
                end
            end
            BuildWeaponsContent()
        elseif name == "Honor Gear" then
            local _, cf = UnitClass("player")
            local cm = {WARRIOR="Warrior",PALADIN="Paladin",HUNTER="Hunter",ROGUE="Rogue",
                        PRIEST="Priest",SHAMAN="Shaman",MAGE="Mage",WARLOCK="Warlock",DRUID="Druid"}
            rfClass = cm[cf or ""] or "Warrior"
            for _, list in ipairs({S1_HONOR_UNIVERSAL, S2_HONOR_UNIVERSAL}) do
                for _, slot in ipairs(list) do
                    for _, item in ipairs(slot.items) do GetItemInfo(item.id) end
                end
            end
            for _, byArmor in ipairs({S1_HONOR_BYARMOR, S2_HONOR_BYARMOR}) do
                for _, armorList in pairs(byArmor) do
                    for _, slot in ipairs(armorList) do
                        for _, item in ipairs(slot.items) do GetItemInfo(item.id) end
                    end
                end
            end
            BuildHonorContent()
        elseif name == "CC/DR Table" then
            BuildDRContent()
        elseif name == "Info" then
            BuildInfoContent()
        end
    end

    -- ── Control button wiring ───────────────────────────────────
    rfSectBtn:SetScript("OnClick", function(self)
        UIDropDownMenu_Initialize(rfSectDD, function()
            for _, sec in ipairs(RF_SECTIONS) do
                local info = UIDropDownMenu_CreateInfo()
                info.text = sec; info.value = sec
                info.notCheckable = true
                info.func = function() SwitchSection(sec); CloseDropDownMenus() end
                UIDropDownMenu_AddButton(info)
            end
        end, "MENU")
        ToggleDropDownMenu(1, nil, rfSectDD, self, 0, -4)
    end)

    rfS1Btn:SetScript("OnClick", function() rfSeason = 1; SwitchSection(rfSection) end)
    rfS2Btn:SetScript("OnClick", function() rfSeason = 2; SwitchSection(rfSection) end)

    rfClassBtn:SetScript("OnClick", function(self)
        UIDropDownMenu_Initialize(rfClassDD, function()
            for _, cls in ipairs(CLASS_LIST) do
                local info = UIDropDownMenu_CreateInfo()
                info.text = cls; info.value = cls
                info.notCheckable = true
                info.func = function()
                    rfClass = cls
                    rfClassBtn:SetText(cls .. "  v")
                    BuildArenaContent()
                    CloseDropDownMenus()
                end
                UIDropDownMenu_AddButton(info)
            end
        end, "MENU")
        ToggleDropDownMenu(1, nil, rfClassDD, self, 0, -4)
    end)

    refFrame:SetScript("OnShow", function()
        local _, cf = UnitClass("player")
        local cm = {WARRIOR="Warrior",PALADIN="Paladin",HUNTER="Hunter",ROGUE="Rogue",
                    PRIEST="Priest",SHAMAN="Shaman",MAGE="Mage",WARLOCK="Warlock",DRUID="Druid"}
        rfClass = cm[cf or ""] or "Warrior"
        rfClassBtn:SetText(rfClass .. "  v")
        SwitchSection(rfSection)
    end)

    BeanArena_OpenRefFrame = function(section, anchorTo)
        if refFrame:IsShown() and rfSection == section then
            refFrame:Hide(); return
        end
        refFrame:ClearAllPoints()
        if anchorTo then refFrame:SetPoint("TOPLEFT", anchorTo, "TOPRIGHT", 6, 0)
        else              refFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 0) end
        SwitchSection(section)
        refFrame:Show()
    end

    BeanArena_RefreshRefFrame = function()
        if refFrame:IsShown() then SwitchSection(rfSection) end
    end
end

-- ============================================================
-- SLASH COMMANDS  ( /ba  and  /beanarena )
-- ============================================================
SLASH_BEANARENA1 = "/ba"; SLASH_BEANARENA2 = "/beanarena"
SlashCmdList["BEANARENA"] = function(msg)
    msg = (msg or ""):lower():trim()
    local cmd, args = msg:match("^(%S+)%s*(.*)$")
    if not cmd then cmd = ""; args = "" end

    local BA = "|cffFFD700[BA]|r"

    local function Toggle(f, anchorTo)
        if f:IsShown() then f:Hide()
        else
            f:ClearAllPoints()
            if anchorTo then f:SetPoint("TOPLEFT", anchorTo, "TOPRIGHT", 6, 0)
            else              f:SetPoint("CENTER", UIParent, "CENTER", 0, 0) end
            f:Show()
        end
    end

    -- ── /ba  or  /ba show ─────────────────────────────────────
    if cmd == "" or cmd == "show" then
        if frame:IsShown() then frame:Hide() else OpenBeanArena() end

    -- ── /ba honor [slot] ──────────────────────────────────────
    -- No arg: open Honor window.  With arg: print cost info for that slot.
    elseif cmd == "honor" then
        if args == "" then
            Toggle(honorFrame, frame)
        else
            local search = args:lower()
            local found = false
            for _, g in ipairs(HONOR_GEAR_FULL) do
                if g.slot:lower():find(search, 1, true) then
                    found = true
                    local honor = GetCurrentHonor()
                    local marks = GetPvPMarkCounts()
                    local have  = honor
                    local need  = g.honor
                    local pct   = math.min(100, math.floor(have / need * 100))
                    local diff  = math.max(0, need - have)
                    local markParts = {}
                    for bg, req in pairs(g.marks) do
                        local h = marks[bg] or 0
                        local mdiff = math.max(0, req - h)
                        local col = h >= req and "00FF00" or "FF4444"
                        markParts[#markParts+1] = string.format("|cff%s%d|r|cffAAAAAA/%d|r %s", col, h, req, bg)
                        if mdiff > 0 then markParts[#markParts] = markParts[#markParts] .. string.format(" |cffFF4444(-%d)|r", mdiff) end
                    end
                    print(string.format("%s Honor Gear: |cffFFD700%s|r", BA, g.slot))
                    print(string.format("  Cost: |cffFFD700%d|r honor  |cffAAAAAA(you have %d — %d%%)|r", need, have, pct))
                    if diff > 0 then
                        print(string.format("  Need: |cffFF4444%d|r more honor  (~|cffAAAAAA%d|r AV wins)", diff, math.ceil(diff/419)))
                    else
                        print("  Honor: |cff00FF00Ready!|r")
                    end
                    print("  Marks: " .. table.concat(markParts, "  "))
                end
            end
            if not found then
                print(BA .. " No honor gear found for: |cffFF4444" .. args .. "|r")
                print("  Slots: Neck, Ring, Bracers, Belt, Boots")
            end
        end

    -- ── /ba arena [slot] ──────────────────────────────────────
    -- No arg: open Arena Gear window.  With arg: print cost info for that slot.
    elseif cmd == "arena" then
        if args == "" then
            BeanArena_OpenRefFrame("Arena Gear", frame)
        else
            local search = args:lower()
            local found = false
            local curAP = GetCurrentArenaPoints()
            for _, g in ipairs(ARENA_GEAR_FULL) do
                if g.slot:lower():find(search, 1, true) then
                    found = true
                    local pct  = math.min(100, math.floor(curAP / g.ap * 100))
                    local diff = math.max(0, g.ap - curAP)
                    print(string.format("%s Arena Gear: |cffFFD700%s|r", BA, g.slot))
                    print(string.format("  Cost: |cffFFD700%d AP|r  |cffAAAAAA(you have %d — %d%%)|r", g.ap, curAP, pct))
                    if diff > 0 then
                        print(string.format("  Need: |cffFF4444%d|r more AP", diff))
                    else
                        print("  AP: |cff00FF00Ready!|r")
                    end
                    if g.rating > 0 then
                        local r2,r3,r5 = GetLiveRatings()
                        local best = math.max(r2,r3,r5)
                        local rCol = best >= g.rating and "00FF00" or "FF4444"
                        print(string.format("  Rating req: |cff%s%d|r  |cffAAAAAA(your best: %d)|r", rCol, g.rating, best))
                    else
                        print("  Rating req: |cff00FF00None|r")
                    end
                end
            end
            if not found then
                print(BA .. " No arena gear found for: |cffFF4444" .. args .. "|r")
                print("  Slots: Gloves, Helmet, Legs, Chest, Shoulders, Shield, Main-hand, etc.")
            end
        end

    -- ── /ba target <ap> ───────────────────────────────────────
    elseif cmd == "target" then
        local ap = tonumber(args)
        if not ap or ap <= 0 then
            print(BA .. " Usage: /ba target <arena points>  e.g. /ba target 1500")
        else
            print(string.format("%s Rating needed to earn |cffFFD700%d AP|r per week:", BA, ap))
            for _, bkt in ipairs({"2v2", "3v3", "5v5"}) do
                local r = CalcRatingForPoints(ap, bkt)
                if r == nil then
                    print(string.format("  %s: |cffFF4444Unreachable|r  |cffAAAAAA(bracket max ~%d AP)|r", bkt, BRACKET_MAX_AP[bkt]))
                elseif r == 0 then
                    print(string.format("  %s: |cff00FF00Any rating|r", bkt))
                else
                    print(string.format("  %s: |cffFFD700%d|r", bkt, r))
                end
            end
        end

    -- ── /ba calc [rating] ─────────────────────────────────────
    -- No arg: use live ratings.  With number: calc that rating for all brackets.
    elseif cmd == "calc" then
        local rating = tonumber(args)
        if rating then
            -- Single rating — show all 3 brackets
            print(string.format("%s Arena Points for rating |cffFFD700%d|r:", BA, rating))
            print(string.format("  2v2: |cffFFD700%.0f AP|r", CalcBracketPoints(rating, "2v2")))
            print(string.format("  3v3: |cffFFD700%.0f AP|r", CalcBracketPoints(rating, "3v3")))
            print(string.format("  5v5: |cffFFD700%.0f AP|r", CalcBracketPoints(rating, "5v5")))
        else
            -- No arg — use live ratings with game check
            local r2,r3,r5,g2,g3,g5 = GetLiveRatings()
            local curAP = GetCurrentArenaPoints()
            local er2=g2>=10 and r2 or 0; local er3=g3>=10 and r3 or 0; local er5=g5>=10 and r5 or 0
            local best, bb = CalcBestPoints(er2,er3,er5)
            print(string.format("%s AP Breakdown  |cffAAAAAA(Banked: %d)|r", BA, curAP))
            local function row(bracket, r, g, er)
                local eligible = er > 0
                local ap = CalcBracketPoints(r, bracket)
                local gstr = g >= 10 and string.format("|cff00FF00%dg|r", g)
                                      or  string.format("|cffFF4444%dg/10|r", g)
                print(string.format("  %s: %d  %s  |cffFFD700%.0f AP|r  total:|cff88FF88%.0f|r%s",
                    bracket, r, gstr, ap, curAP+ap,
                    eligible and "" or "  |cffAAAAAA(need 10 games)|r"))
            end
            row("2v2", r2, g2, er2)
            row("3v3", r3, g3, er3)
            row("5v5", r5, g5, er5)
            if best > 0 then
                print(string.format("  Best eligible: |cffFFD700%.0f AP|r from |cffFFD700%s|r", best, bb))
            end
        end

    -- ── /ba dr [class] ────────────────────────────────────────
    -- No arg: list all classes.  With class: print that class's CC and shared DRs.
    elseif cmd == "dr" or cmd == "cc" then
        if args == "" then
            BeanArena_OpenRefFrame("CC/DR Table", frame)
        else
            -- Match class name (partial ok)
            local search = args:lower()
            local matchClass, matchData = nil, nil
            for cls, data in pairs(CLASS_CC) do
                if cls:lower():find(search, 1, true) then
                    matchClass = cls; matchData = data; break
                end
            end
            if not matchClass then
                print(BA .. " Unknown class: |cffFF4444" .. args .. "|r")
                local cls_list = {}
                for c in pairs(CLASS_CC) do cls_list[#cls_list+1] = c end
                table.sort(cls_list)
                print("  Classes: " .. table.concat(cls_list, ", "))
            else
                print(string.format("%s DR table for |cffFFD700%s|r:", BA, matchClass))
                -- Group by DR category
                local byDR = {}
                for _, cc in ipairs(matchData) do
                    byDR[cc.dr] = byDR[cc.dr] or {}
                    table.insert(byDR[cc.dr], cc)
                end
                for drId, spells in pairs(byDR) do
                    -- Find DR category info
                    local catName, catColor = drId, "AAAAAA"
                    for _, cat in ipairs(DR_CATEGORIES) do
                        if cat.id == drId then catName = cat.name; catColor = cat.color; break end
                    end
                    -- Collect all OTHER classes that share this DR
                    local sharedWith = {}
                    for cls2, data2 in pairs(CLASS_CC) do
                        if cls2 ~= matchClass then
                            for _, cc2 in ipairs(data2) do
                                if cc2.dr == drId then
                                    sharedWith[cls2] = true; break
                                end
                            end
                        end
                    end
                    local shareList = {}
                    for c in pairs(sharedWith) do shareList[#shareList+1] = c end
                    table.sort(shareList)
                    local shareStr = #shareList > 0 and ("|cffAAAAAA(shared w/ " .. table.concat(shareList, ", ") .. ")|r") or ""
                    print(string.format("  |cff%s[%s]|r %s", catColor, catName, shareStr))
                    for _, s in ipairs(spells) do
                        print(string.format("    |cffFFD700%s|r %s  |cffAAAAAA%s|r", s.spell, s.dur, s.notes))
                    end
                end
            end
        end

    -- ── /ba points ────────────────────────────────────────────
    elseif cmd == "points" or cmd == "rating" then
        -- Same as /ba calc with no arg
        local r2,r3,r5,g2,g3,g5 = GetLiveRatings()
        local curAP = GetCurrentArenaPoints()
        local er2=g2>=10 and r2 or 0; local er3=g3>=10 and r3 or 0; local er5=g5>=10 and r5 or 0
        local best, bb = CalcBestPoints(er2, er3, er5)
        print(string.format("%s Ratings  |cffAAAAAA(Banked: %d AP)|r", BA, curAP))
        local function pr(b, r, g)
            local ap = CalcBracketPoints(r, b)
            print(string.format("  %s: %d  %s  |cffFFD700%.0fAP|r",
                b, r, g>=10 and string.format("|cff00FF00%dg|r",g) or string.format("|cffFF4444%dg/10|r",g), ap))
        end
        pr("2v2",r2,g2); pr("3v3",r3,g3); pr("5v5",r5,g5)
        print(best>0 and string.format("  Best: |cffFFD700%.0fAP|r (%s)", best, bb) or "  |cffAAAAAA(No eligible bracket — need 10 games)|r")

    -- ── /ba alts ──────────────────────────────────────────────
    elseif cmd == "alts" then
        local alts = BeanArena_GetAltData()
        -- Class color table (TBC class file names → hex)
        local CLASS_COLORS = {
            WARRIOR="C79C6E", PALADIN="F58CBA", HUNTER="ABD473", ROGUE="FFF569",
            PRIEST="FFFFFF", SHAMAN="0070DE", MAGE="69CCF0", WARLOCK="9482C9",
            DRUID="FF7D0A", DEATHKNIGHT="C41F3B",
        }
        local myKey = (CHAR_NAME or "") .. "-" .. (CHAR_REALM or "")
        local printed = 0
        print("|cffFFD700[BA]|r Alts:")
        for _, a in ipairs(alts) do
            local key = a.name .. "-" .. (a.realm or "")
            if key ~= myKey then
                local cc = CLASS_COLORS[a.class] or "AAAAAA"
                local ts = a.lastSeen and date("%m/%d", a.lastSeen) or "?"
                print(string.format("  |cff%s%-12s|r  2v2:|cffFFD700%d|r  3v3:|cffFFD700%d|r  AP:|cff88FF88%d|r  |cffAAAAAA(%s)|r",
                    cc, a.name, a.rating2v2 or 0, a.rating3v3 or 0, a.arenaPoints or 0, ts))
                printed = printed + 1
            end
        end
        if printed == 0 then
            print("  |cffAAAAAANo alt data yet. Log in on your alts to populate.|r")
        end

    -- ── /ba reset ─────────────────────────────────────────────
    elseif cmd == "reset" then
        print(BA .. " Reset in: |cff00CCFF" .. GetDaysToReset() .. "|r")

    -- ── /ba marks ─────────────────────────────────────────────
    elseif cmd == "marks" then
        local m = GetPvPMarkCounts()
        print(BA .. " BG Marks:")
        local order = {"AV","WSG","AB","EotS"}
        for _, bg in ipairs(order) do
            print(string.format("  %s: |cffFFD700%d|r", bg, m[bg] or 0))
        end

    -- ── /ba slots [arena|honor] ──────────────────────────────────
    elseif cmd == "slots" then
        local which = args:lower()
        if which == "" or which == "arena" then
            local slots = {}
            for _, g in ipairs(ARENA_GEAR_FULL) do slots[#slots+1] = g.slot end
            print("|cffFFD700[BA]|r Arena slots: " .. table.concat(slots, ", "))
        end
        if which == "" or which == "honor" then
            local slots = {}
            for _, g in ipairs(HONOR_GEAR_FULL) do slots[#slots+1] = g.slot end
            print("|cffFFD700[BA]|r Honor slots: " .. table.concat(slots, ", "))
        end
        if which ~= "" and which ~= "arena" and which ~= "honor" then
            print("|cffFFD700[BA]|r Usage: /ba slots  |  /ba slots arena  |  /ba slots honor")
        end

    -- ── /ba gear  /ba hgear ───────────────────────────────────
    elseif cmd == "gear" or cmd == "arenagear" then
        BeanArena_OpenRefFrame("Arena Gear", frame)
    elseif cmd == "hgear" or cmd == "honorgear" then
        BeanArena_OpenRefFrame("Honor Gear", frame)
    elseif cmd == "weapons" then
        BeanArena_OpenRefFrame("Weapons", frame)

    -- ── /ba info  /ba chars  /ba commands ─────────────────────
    elseif cmd == "info" then
        BeanArena_OpenRefFrame("Info", frame)
    elseif cmd == "chars" or cmd == "characters" then
        Toggle(charViewFrame, frame)
    elseif cmd == "commands" then
        if cFrame:IsShown() then cFrame:Hide() else OpenCommands() end

    -- ── /ba options ───────────────────────────────────────────
    elseif cmd == "options" then ShowOptions()

    -- ── /ba help ──────────────────────────────────────────────
    elseif cmd == "help" then
        print("|cffFFD700[BA]|r Commands — /ba {command}")
        print("  |cffFFD700Windows:|r  /ba  honor  gear  hgear  cc  info  chars")
        print("  |cffFFD700Lookup:|r   calc [#]  target <ap>  honor [slot]  arena [slot]  dr [class]")
        print("  |cffFFD700Lists:|r    slots  slots arena  slots honor")
        print("  |cffFFD700Other:|r    alts  points  marks  reset  help")

    else
        print(BA .. " Unknown: |cffFF4444/ba " .. cmd .. "|r  —  try |cffFFD700/ba help|r")
    end
end

-- ============================================================
-- EVENTS
-- ============================================================
-- Set when GET_ITEM_INFO_RECEIVED fires while a gear popup is open;
-- cleared by the OnUpdate ticker which then rebuilds the popup once.
local itemRefreshPending = false

local eFrame = CreateFrame("Frame")
eFrame:RegisterEvent("ADDON_LOADED")
eFrame:RegisterEvent("PLAYER_LOGIN")
eFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eFrame:RegisterEvent("UPDATE_BATTLEFIELD_STATUS")
eFrame:RegisterEvent("GET_ITEM_INFO_RECEIVED")

eFrame:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" and type(arg1)=="string" and arg1:lower() == ADDON_NAME:lower() then
        -- Initialize minimap sub-table with defaults
        BeanArenaDB.minimap = BeanArenaDB.minimap or {}
        local mm = BeanArenaDB.minimap
        if mm.position     == nil then mm.position     = 225   end
        if mm.distance     == nil then mm.distance     = 1     end
        if mm.visible      == nil then mm.visible      = true  end
        if mm.lock         == nil then mm.lock         = false end
        if mm.lockDistance == nil then mm.lockDistance = false end
        -- Initialize alt data table
        BeanArenaDB.altData = BeanArenaDB.altData or {}
        -- Restore main frame position
        if DB("frameX") and DB("frameY") then
            frame:ClearAllPoints()
            frame:SetPoint("CENTER", UIParent, "BOTTOMLEFT", DB("frameX"), DB("frameY"))
        else
            frame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
        end
        UpdateMinimapPos()
        SetupPVPHook()
        print("|cffFFD700[BeanArena]|r v0.3.6 loaded! /ba help")
        if DB("openOnLogin") then OpenBeanArena() end
    elseif event == "PLAYER_LOGIN" then
        CHAR_NAME  = UnitName("player") or "Unknown"
        CHAR_REALM = GetRealmName and GetRealmName() or "Unknown"
        SnapshotCharData()
        -- Set dropdown to current char
        UIDropDownMenu_SetText(charDD, "|cffFFD700" .. CHAR_NAME .. " (you)|r")
    elseif event == "PLAYER_ENTERING_WORLD" then
        if RequestPVPRewardsUpdate then RequestPVPRewardsUpdate() end
        if frame:IsShown() then BeanArena_RefreshFrame() end
        -- Update snapshots with fresh live data after ratings have loaded
        if C_Timer and C_Timer.After then
            C_Timer.After(3, function()
                SnapshotCharData()
                WriteAltSnapshot()
            end)
        end
    elseif event == "UPDATE_BATTLEFIELD_STATUS" then
        if frame:IsShown() then BeanArena_RefreshFrame() end
    elseif event == "GET_ITEM_INFO_RECEIVED" then
        -- Flag a rebuild so icons that loaded after a popup opened get shown.
        -- The OnUpdate ticker consumes the flag and does a single rebuild.
        if refFrame and refFrame:IsShown() then
            itemRefreshPending = true
        end
    end
end)

-- ============================================================
-- PVP UI HOOK  — open BeanArena alongside the PvP frame (H key)
-- ============================================================
local pvpHookDone = false
SetupPVPHook = function()
    if pvpHookDone then return end
    pvpHookDone = true
    -- Hook the PvP frame show (opened by H key in TBC)
    if PVPFrame then
        PVPFrame:HookScript("OnShow", function()
            if not frame:IsShown() then
                frame:ClearAllPoints()
                -- Position BeanArena to the right of PVPFrame
                frame:SetPoint("TOPLEFT", PVPFrame, "TOPRIGHT", 6, 0)
                OpenBeanArena()
            end
        end)
        PVPFrame:HookScript("OnHide", function()
            frame:Hide()
        end)
    end
end

-- ============================================================
-- TICKER  (refresh every 5s while frame is visible)
-- ============================================================
local ticker = 0
frame:SetScript("OnUpdate", function(self, elapsed)
    -- Rebuild gear popup once after item icons finish loading
    if itemRefreshPending then
        itemRefreshPending = false
        if refFrame:IsShown() then BeanArena_RefreshRefFrame() end
    end
    ticker = ticker + elapsed
    if ticker >= 5 then
        ticker = 0
        if viewingSnap == nil then RefreshLive() end; RefreshMisc()
        if not editFocused["manual2v2"] then man2v2Edit:SetText(tostring(DB("manual2v2"))) end
        if not editFocused["manual3v3"] then man3v3Edit:SetText(tostring(DB("manual3v3"))) end
        if not editFocused["manual5v5"] then man5v5Edit:SetText(tostring(DB("manual5v5"))) end
    end
end)

-- ============================================================
-- END OF FILE | BeanArena v0.3.6 | 2026-05-21
-- ============================================================
